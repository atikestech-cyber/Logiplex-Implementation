package sailpoint.services.standard.connector;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import sailpoint.api.IdentityService;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.connector.AbstractConnector;
import sailpoint.connector.AuthenticationFailedException;
import sailpoint.connector.Connector;
import sailpoint.connector.ConnectorException;
import sailpoint.connector.ConnectorFactory;
import sailpoint.connector.ExpiredPasswordException;
import sailpoint.connector.ObjectNotFoundException;
import sailpoint.object.Application;
import sailpoint.object.Application.Feature;
import sailpoint.object.AttributeDefinition;
import sailpoint.object.Attributes;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.ManagedAttribute;
import sailpoint.object.Partition;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AbstractRequest;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.ProvisioningPlan.ObjectOperation;
import sailpoint.object.ProvisioningPlan.ObjectRequest;
import sailpoint.object.ProvisioningResult;
import sailpoint.object.QueryOptions;
import sailpoint.object.Resolver;
import sailpoint.object.ResourceObject;
import sailpoint.object.Rule;
import sailpoint.object.Schema;
import sailpoint.tools.CloseableIterator;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;
import sailpoint.tools.Util;
import sailpoint.tools.xml.AbstractXmlObject;
import sailpoint.tools.xml.XMLReferenceResolver;

/**
 * This connector is meant to be a replacement for the Logical Connector. The
 * Logical connector's purpose is to allow some subsets accounts and their
 * access rights to be represented as a logical grouping, as an application.
 * <p>
 * The Logical connector supports both subsets of an application (single tier)
 * and combining multiple application accounts into a single, logical account
 * (multiple tiers). This connector mainly supports a single tier scenario, but
 * a customization rule or the LogiPlex split rule could be used to perform
 * side-lookups.
 *
 * @author menno.pieters@sailpoint.com
 *
 * 2019.11.25-0001: Fix for plan optimization
 * 2019.11.26-0001: Simulation mode
 * 2019.12.01-0001: Tests for fix in 2019.11.25-0001
 * 2019.12.01-0002: Fix for typo in plan optimization
 * 2019.12.01-0003: No longer merging Create requests in plan optimization, turn additional into Modify
 * 2019.12.01-0004: Removed unused code due to changes in optimization strategy
 * 2020.03.26-0003: Additional checks for password reset
 * 2020.04.13-0011: Fix for getObject operation not returning the correct object for a sub-application
 * 2020.04.15-0001: Fix for feature set
 * 2020.05.25-0002: Fix for classic mode split rule usage and mapToList
 * 2020.07.03-0001: Cloud Gateway support test
 * 2020.07.07-0001: Cloud Gateway support implemented.
 * 2020.07.09-0003: Cloud Gateway support improved.
 * 2020.07.22-0001: Bug fix: PLSI-892: PLSI-892 incorrect list of entitlements after LCM access request
 * 2020.07.23-0001: PLSI-894: Added support for ActiveDirectory account rename and move operations
 * 2020.07.30-0001: Minor fix for provisioning results
 * 2021.01.11-0001: Potential fix for applications that generate their own value for the native identity after provisioning.
 * 2021.01.12-0006: Split rule executed during authentication, too.
 * 2021.01.12-0007: Removed e.printStackTrace() due to security conceers.
 * 2021.01.13-0004: Fix handling native identity for account requests.
 * 2021.12.13-0000: Fix for CVE-2021-44228 - no actual change in connector, just build-dependencies.
 * 2021.12.20-0001: Initial fix for PLSI-1214.
 * 2021.12.23-0001: Change the way the real connector is instantiated. 
 * 2022.01.11-0001: Static class name check for CIBConnector to prevent class loading issue on sub-applications.
 * 2022.01.19-0002: Optional cloning of application definition before creating the real connector.
 * 2022.03.15-0003: Fix for delta aggregation information not being updated.
 * 2022.04.06-0002: Additional check to prevent returning null objects, fix object count.
 * 2022.05.16-0001: Hardcoded ADLDAPConnector class due to class loading issues with 8.1p4, 8.2p1 and up.
 * 2023.03.27-0001: Updated logic for account moves (AC_newParent and AC_newName) to not execute if the account identifier is not a DN.
 * 2023.03.31-0001: Fix for account moves on AD (IndexOutOfBoundsException).
 * 2023.04.17-0001: Fix for handling enable/disable/lock/unlock with respect to sub-applications.
 */
public class LogiPlexConnector extends AbstractConnector {

	public final static String VERSION = "2023.04.17.0001";

	// Application attributes
	// - Classic mode: master application
	public final static String LOGIPLEX_ATTR_MASTER_APPLICATION = "masterApplication";
	// - Adapter mode: real connector to use
	public final static String LOGIPLEX_ATTR_MASTER_CONNECTOR = "logiPlexMasterConnector";
	// - Classic mode: use link from the master application instead of main application
	public final static String LOGIPLEX_ATTR_LINK_FROM_MASTER = "linkFromMaster";
	// - Re-get the object after provisioning to fill in the provisioning result
	public final static String LOGIPLEX_ATTR_PROVISION_GET_OBJECT = "logiPlexUseGetObject";
	// - Delay for re-aggregation after provisioning
	public final static String LOGIPLEX_ATTR_RE_AGGREGATE_DELAY = "logiPlexReAggregateDelay";
	// - For testing: simulate provisioning
	public final static String LOGIPLEX_ATTR_SIMULATE_PROVISIONING = "logiPlexSimulateProvisioning";
	// - For testing: result for simulated provisioning
	public final static String LOGIPLEX_ATTR_SIMULATE_PROVISIONING_RESULT = "logiPlexSimulateProvisioningResult";
	// - The proxy (main application) for sub-application. This option survives the transfer to the Cloud Gateway
	// Used when the Cloud Gateway is defined as proxy on the main application in adapter mode.
	public final static String LOGIPLEX_ATTR_CGW_PROXY_APPLICATION = "logiPlexCGWProxyApplication";
	// - The Cloud Gateway, if not specified as proxy on the main application (preferred method).
	public final static String LOGIPLEX_ATTR_CGW_APPLICATION = "logiPlexCloudGatewayApplication";
	// - If true, clone the application definition before creating the connector.
	public final static String LOGIPLEX_ATTR_CLONE_APPLICATION = "logiPlexCloneApplication";
	
	// - Prefix to use for new application names
	public final static String LOGIPLEX_ATTR_PREFIX = "logiPlexPrefix";
	public final static String LOGIPLEX_PREFIX = LOGIPLEX_ATTR_PREFIX; // Reverse compatibility

	// Rules
	public final static String LOGIPLEX_AGGREGATION_RULE = "logiPlexAggregationRule";
	public final static String LOGIPLEX_PROVISIONING_RULE = "logiPlexProvisioningRule";

	// Flag that indicates that ResourceObject has been retrieved during authentication
	public static final String LOGIPLEX_AUTHENTICATE_OBJECT = "logiPlexAuthenticateObject";

	public final static String CONNECTOR_TYPE = "LogiPlex Connector";

	// Provisioning Plan Arguments
	public final static String ARG_ORIGINAL_TARGET_APP = "logiPlexOrginalApplication";
	public static final String ARG_LOGIPLEX_TRACKING_ID = "logiplexTrackingId";
	public static final String ARG_LOGIPLEX_PLAN_IDENTITY = "logiPlexEmbeddedIdentity";
	
	// Connector Class Names
	public static final String CIB_CONNECTOR_CLASS = "sailpoint.connector.cib.CIBConnector";
	private static final String ADLDAP_CONNECTOR_CLASS = "sailpoint.connector.ADLDAPConnector";

	private final Logger log = Logger.getLogger(LogiPlexConnector.class);

	private Application masterApplication = null;
	private Connector masterConnector = null;
	private boolean useCloudGateway = false;
	private boolean useCloudGatewayLocal = false;
	private SailPointContext context;
	private LogiPlexUtil util = null;
	private List<String> subApplicationNames = null;

	/**
	 * Standard constructor.
	 *
	 * @param application
	 *            Application definition containing the connector parameters,
	 *            schema, etc.
	 * @throws GeneralException
	 */
	public LogiPlexConnector(final Application application) throws GeneralException {
		super(application);
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Constructor: LogiPlexConnector(%s)", application)));
		}
		init(application);
	}

	/**
	 * Constructor when using instances.
	 *
	 * @param application
	 *            Application definition containing the connector parameters,
	 *            schema, etc.
	 * @param instance
	 *            Application instance
	 * @throws GeneralException
	 */
	public LogiPlexConnector(final Application application, final String instance) throws GeneralException {
		super(application, instance);
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Constructor: LogiPlexConnector(%s, %s)", application, instance)));
		}
		init(application, instance);
	}

	/**
	 * Called from the constructor to initialize the connector.
	 *
	 * @param application
	 *            Application definition containing the connector parameters,
	 *            schema, etc.
	 * @throws GeneralException
	 */
	private void init(Application application) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: init(%s)", application)));
		}
		init(application, null);
	}

	/**
	 * Get a connector for the application by cloning the base application and overriding the connector.
	 * 
	 * This method requires the attribute useConnectorClassloader to be set to true in the application definition.
	 * 
	 *       <entry key="useConnectorClassloader" value="true"/>
	 *       
	 * If the settings logiPlexCloneApplication is set to true, the application will be cloned before updating with the "real" connector. 
	 *       
	 *       <entry key="logiPlexCloneApplication" value="true"/>
	 * 
	 * @param connectorName
	 * @param application
	 * @param instance
	 * @return
	 * @throws GeneralException
	 */
	private Connector createConnector(String connectorName, Application application, String instance) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: createConnector(%s, %s, %s)", connectorName, application, instance)));
		}
		if (application != null && Util.isNotNullOrEmpty(connectorName)) {
			if (getBooleanArgument(LOGIPLEX_ATTR_CLONE_APPLICATION, false)) {
				log.debug("createConnector: Cloning the application definition for connector instantiation");
				Application clonedApplication = (Application) application.deepCopy((Resolver) context);
				String applicationName = "LOGIPLEX-TEMP-" + application.getName();
				clonedApplication.setConnector(connectorName);
				clonedApplication.setName(applicationName);
				Connector connector = ConnectorFactory.getConnector(clonedApplication, instance);
				connector.setTargetApplication(application);
				return connector;
			} else {
				Connector connector = null;
				try {
					log.debug("createConnector: updating real connector on the the application definition for connector instantiation");
					// Set Real Connector
					application.setConnector(connectorName);
					connector = ConnectorFactory.getConnector(application, instance);
				} finally {
					// Restore LogiPlex
					log.debug("createConnector: restoring the application definition for connector instantiation");
					application.setConnector(LogiPlexConnector.class.getName());
					if (connector != null) {
						connector.setTargetApplication(application);
					}
				}
				return connector;
			}
		}
		return null;
	}

	/**
	 * Called from the constructor to initialize the connector. This method will
	 * initialize the connector configuration. To do so, it needs to figure out
	 * which application is the main and/or master application and which
	 * connector to use to connect to the target system. While doing that, it
	 * may also need to check any proxies, in case a cloud connector gateway is
	 * used.
	 *
	 * @param application
	 *            Application definition containing the connector parameters,
	 *            schema, etc.
	 * @param instance
	 * @throws GeneralException
	 */
	private void init(Application application, String instance) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: init(%s, %s)", application, instance)));
			log.debug(LogiPlexTools.stripControls(String.format("LogiPlex Connector Version: %s", VERSION)));
		}
		context = SailPointFactory.getCurrentContext();
		Application mainApplication = LogiPlexTools.getMainApplication(context, application);

		// Try to get the master application from the application definition.
		String masterApplicationId = application.getStringAttributeValue(LOGIPLEX_ATTR_MASTER_APPLICATION);
		if (application.getId() != null || masterApplicationId != null) {
			/*
			 * This part is only called in case that the connector is
			 * instantiated for 'real' work: preview, aggregation, provisioning.
			 */
			if (log.isTraceEnabled()) {
				log.trace("Instantiating LogiPlex Connector");
			}

			Application proxyApplication = null;
			if (Util.isNullOrEmpty(masterApplicationId)) {
				proxyApplication = application.getProxy();
				if (proxyApplication != null) {
					log.debug("No master application found. Found proxy: checking proxy for master application.");
					masterApplicationId = proxyApplication.getStringAttributeValue(LOGIPLEX_ATTR_MASTER_APPLICATION);
				}
			}

			if (log.isDebugEnabled()) {
				log.debug(LogiPlexTools.stripControls(String.format("Master application: %s", masterApplicationId)));
				if (proxyApplication != null) {
					log.debug(LogiPlexTools.stripControls(String.format("Proxy application: %s", proxyApplication.getName())));

				}
			}

			if (Util.isNullOrEmpty(masterApplicationId) || Util.nullSafeEq(masterApplicationId, application.getId())) {
				/*
				 * Adapter mode: master = main. In adapter mode there is no
				 * longer separation between the main and master configuration.
				 */
				if (log.isDebugEnabled()) {
					log.debug("Adapter Mode - Getting Connector");
				}
				String cloudGatewayApplicationName = null;
				Application cloudGatewayApplication = null;
				if (mainApplication != null) {
					cloudGatewayApplicationName = mainApplication.getStringAttributeValue(LOGIPLEX_ATTR_CGW_APPLICATION);
					if (Util.isNotNullOrEmpty(cloudGatewayApplicationName)) {
						if (log.isTraceEnabled()) {
							log.trace("Main application has setting " + LOGIPLEX_ATTR_CGW_APPLICATION + " defined. Trying Cloud Gateway for all traffic.");
						}
						cloudGatewayApplication = context.getObject(Application.class, cloudGatewayApplicationName);
						if (!CIB_CONNECTOR_CLASS.equals(cloudGatewayApplication.getConnector())) {
							throw new GeneralException(LogiPlexTools.stripControls(String.format("Application %s is not a Cloud Gateway", cloudGatewayApplicationName)));
						}
						if (log.isTraceEnabled()) {
							log.trace(LogiPlexTools.stripControls(String.format("Selected Cloud Gateway %s for all traffic.", cloudGatewayApplicationName)));
						}
					}
				}

				String masterConnectorName = null;
				if (cloudGatewayApplication != null) {
					if (log.isDebugEnabled()) {
						log.debug(LogiPlexTools.stripControls(String.format("All Traffic via Cloud Gateway %s, local processing", cloudGatewayApplicationName)));
					}
					useCloudGateway = true;
					useCloudGatewayLocal = true;
					masterConnectorName = CIB_CONNECTOR_CLASS;
					masterConnector = ConnectorFactory.getConnector(cloudGatewayApplication, instance);
					masterConnector.setTargetApplication(mainApplication);
				} else if (proxyApplication != null && CIB_CONNECTOR_CLASS.equals(proxyApplication.getConnector())) {
					// Main/master with Cloud Gateway
					if (log.isDebugEnabled()) {
						log.debug(String.format("Master Application %s, via Cloud Gateway %s", application.getName(), proxyApplication.getName()));
					}
					useCloudGateway = true;
					masterConnectorName = CIB_CONNECTOR_CLASS;
					masterConnector = ConnectorFactory.getConnector(proxyApplication, instance);
					if (masterConnector == null) {
						log.error("Null connector for Cloud Gateway");
						throw new GeneralException("Null connector for Cloud Gateway");
					}
					masterConnector.setTargetApplication(application);
				} else if (proxyApplication != null && proxyApplication.getProxy() != null && CIB_CONNECTOR_CLASS.equals(proxyApplication.getProxy().getConnector())) {
					// Sub-application or main/master with Cloud Gateway
					if (log.isDebugEnabled()) {
						log.debug(LogiPlexTools.stripControls(
								String.format("Sub-Application %s, proxy %s via Cloud Gateway %s", application.getName(), proxyApplication.getName(), proxyApplication.getProxy().getName())));
					}
					useCloudGateway = true;
					masterConnectorName = CIB_CONNECTOR_CLASS;
					masterConnector = ConnectorFactory.getConnector(proxyApplication.getProxy(), instance);
					if (masterConnector == null) {
						log.error("Null connector for Cloud Gateway");
						throw new GeneralException("Null connector for Cloud Gateway");
					}
					masterConnector.setTargetApplication(application);
					masterConnector.setTargetInstance(instance);
				} else {
					masterConnectorName = application.getStringAttributeValue(LOGIPLEX_ATTR_MASTER_CONNECTOR);
					if (Util.isNullOrEmpty(masterConnectorName) && proxyApplication != null) {
						if (log.isDebugEnabled()) {
							log.debug(LogiPlexTools
									.stripControls(String.format("Application %s does not specify a master connector, checking proxy %s", application.getName(), proxyApplication.getName())));
						}
						masterConnectorName = proxyApplication.getStringAttributeValue(LOGIPLEX_ATTR_MASTER_CONNECTOR);
					}
					if (Util.isNotNullOrEmpty(masterConnectorName)) {
						if (log.isTraceEnabled()) {
							log.trace(String.format("Adapter mode: Using LogiPlex Master Connector %s", masterConnectorName));
						}
						boolean proxyIsLogiPlex = ((proxyApplication != null) && (LogiPlexConnector.class.getName().equals(proxyApplication.getConnector())));
						masterApplication = ((proxyIsLogiPlex) ? proxyApplication : application);
						masterConnector = createConnector(masterConnectorName, masterApplication, instance);
						if (log.isTraceEnabled()) {
							log.trace(String.format("Adapter mode: Using LogiPlex Master Connector  (%s) %s", masterApplication.getName(), masterApplication.getConnector()));
						}
					} else {
						/*
						 * This indicates a configuration issue.
						 */
						log.warn("No master application or connector defined");
					}
				}
			} else {
				/*
				 * Classic mode: master != main. In classic mode there is a
				 * separate application definition for the master and the main
				 * application. The main application must specify the master
				 * application name or id.
				 */
				if (log.isDebugEnabled()) {
					log.debug("Classic Mode - Getting Connector");
				}
				masterApplication = context.getObject(Application.class, masterApplicationId);
				if (masterApplication == null) {
					throw new GeneralException("Cannot resolve master application " + masterApplicationId);
				}
				super.setApplication(masterApplication);
				masterConnector = ConnectorFactory.getConnector(masterApplication, instance);
			}
			if (masterConnector == null) {
				throw new GeneralException(String.format("Cannot instantiate master connector for application %s", (application == null) ? "NULL" : application.getName()));
			}
		} else {
			/*
			 * Dummy instance: this is called for example when opening the
			 * application definition. There is no need to instantiate the
			 * master connector.
			 */
			log.info("Dummy instance, no id - ignoring");
		}

		if (masterApplication == null) {
			if (log.isDebugEnabled()) {
				log.debug("Setting master to main application");
			}
			// Assuming master = main
			masterApplication = mainApplication;
		}

		/*
		 * Instantiate the LogiPlexUtil class, which provided utility methods
		 * used during aggregation and provisioning.
		 */
		if (mainApplication == null) {
			this.util = new LogiPlexUtil(context, application.getName(), application.getAttributes());
		} else {
			this.util = new LogiPlexUtil(context, mainApplication.getName(), mainApplication.getAttributes());
		}
	}

	/**
	 * Get an boolean application option. Try the current application first, then the main application. If not found return 0.
	 *
	 * @param name
	 * @return
	 * @throws GeneralException
	 */
	@SuppressWarnings("unused")
	private boolean getBooleanArgument(String name) throws GeneralException {
		return getBooleanArgument(name, false);
	}

	/**
	 * Get an integer application option. Try the current application first, then the main application. If not found return the provided default.
	 *
	 * @param name
	 * @return
	 * @throws GeneralException
	 */
	private boolean getBooleanArgument(String name, boolean defaultValue) throws GeneralException {
		Application mainApplication = LogiPlexTools.getMainApplication(context, this.getApplication());
		Attributes<String, Object> args = this.getApplication().getAttributes();
		if (args.containsKey(name)) {
			if (args.get(name) != null) {
				return args.getBoolean(name);
			}
		}
		args = mainApplication.getAttributes();
		if (args.containsKey(name)) {
			if (args.get(name) != null) {
				return args.getBoolean(name);
			}
		}
		return defaultValue;
	}

	/**
	 * Get a string application option. Try the current application first, then the main application. If not found return null.
	 *
	 * @param name
	 * @return
	 * @throws GeneralException
	 */
	private String getStringArgument(String name) throws GeneralException {
		return getStringArgument(name, null);
	}

	/**
	 * Get a string application option. Try the current application first, then the main application. If not found return the provided default.
	 *
	 * @param name
	 * @param defaultValue
	 * @return
	 * @throws GeneralException
	 */
	private String getStringArgument(String name, String defaultValue) throws GeneralException {
		Application mainApplication = LogiPlexTools.getMainApplication(context, this.getApplication());
		Attributes<String, Object> args = this.getApplication().getAttributes();
		if (args.containsKey(name)) {
			if (args.get(name) != null) {
				return args.getString(name);
			}
		}
		args = mainApplication.getAttributes();
		if (args.containsKey(name)) {
			if (args.get(name) != null) {
				return args.getString(name);
			}
		}
		return defaultValue;
	}

	/**
	 * Get an integer application option. Try the current application first, then the main application. If not found return 0.
	 *
	 * @param name
	 * @return
	 * @throws GeneralException
	 */
	private int getIntegerArgument(String name) throws GeneralException {
		return getIntegerArgument(name, 0);
	}

	/**
	 * Get an integer application option. Try the current application first, then the main application. If not found return the provided default.
	 *
	 * @param name
	 * @return
	 * @throws GeneralException
	 */
	private int getIntegerArgument(String name, int defaultValue) throws GeneralException {
		Application mainApplication = LogiPlexTools.getMainApplication(context, this.getApplication());
		Attributes<String, Object> args = this.getApplication().getAttributes();
		if (args.containsKey(name)) {
			if (args.get(name) != null) {
				return args.getInt(name);
			}
		}
		args = mainApplication.getAttributes();
		if (args.containsKey(name)) {
			if (args.get(name) != null) {
				return args.getInt(name);
			}
		}
		return defaultValue;
	}

	@Override
	public String getConnectorType() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getConnectorType()");
		}
		return CONNECTOR_TYPE;
	}

	@Override
	public List<Feature> getSupportedFeatures() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getSupportedFeatures()");
		}
		/*
		 * Deprecated function, but kept for compatibility reasons.
		 */
		return this.getApplication().getFeatures();
	}

	/**
	 * Get a single account or group object.
	 *
	 * @param objectType
	 * @param identityName
	 * @param options
	 * @return
	 * @throws ConnectorException
	 */
	public ResourceObject getObject(final String objectType, final String identityName, final Map<String, Object> options) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: getObject(%s, %s, %s)", objectType, identityName, options)));
		}
		if (masterConnector == null) {
			throw new ConnectorException("No master connector set");
		}
		ResourceObject object = this.masterConnector.getObject(objectType, identityName, options);
		if (this.useCloudGateway && !this.useCloudGatewayLocal) {
			// Split is performed on the Cloud Gateway.
			return object;
		}
		Map<String, ResourceObject> objects;
		try {
			objects = util.splitResourceObject(object);
			if (log.isTraceEnabled() && objects != null) {
				log.trace("START: ResourceObjects after split");
			}
			for (String roKey : objects.keySet()) {
				ResourceObject ro = objects.get(roKey);
				ro.put("IIQSourceApplication", roKey);
				if (log.isTraceEnabled() && objects != null) {
					log.trace(LogiPlexTools.stripControls(String.format("%s: %s\n", roKey, (ro != null) ? ro.toXml() : "NULL")));
				}
			}
			if (log.isTraceEnabled() && objects != null) {
				log.trace("END:   ResourceObjects after split");
			}
			String targetApplicationName = null;
			Application targetApplication = getTargetApplication();
			if (targetApplication == null) {
				targetApplicationName = this.getApplication().getName();
			} else {
				targetApplicationName = targetApplication.getName();
			}

			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("getObject: application names: %s", objects.keySet())));
				log.trace(LogiPlexTools.stripControls(String.format("getObject: target application: %s", targetApplicationName)));
			}
			return objects.get(targetApplicationName);
		} catch (GeneralException e) {
			log.error(e);
			throw new ConnectorException(e);
		}
	}

	/**
	 * For two list, sort the contents and verify equality.
	 *
	 * @param list1
	 * @param list2
	 * @return
	 */
	private boolean equalStringLists(final List<String> list1, final List<String> list2) {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: equalStringLists(%s, %s)", list1, list2)));
		}
		if (list1 != null && list2 != null) {
			List<String> l1 = new ArrayList<String>();
			List<String> l2 = new ArrayList<String>();
			l1.addAll(list1);
			l2.addAll(list2);
			Collections.sort(l1);
			Collections.sort(l2);
			return (l1.equals(l2));
		}
		return false;
	}

	/**
	 * Check whether the Filter represents filter for the authentication attributes.
	 *
	 * @param filter
	 * @return true if the filter is a filter for only the authentication attributes defined on the application definition.
	 *
	 */
	private boolean isAuthenticationFilter(Filter filter) {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: isAuthenticationFilter(%s)", filter)));
		}
		if (filter != null && filter instanceof Filter.CompositeFilter) {
			Filter.CompositeFilter cf = (Filter.CompositeFilter) filter;
			if (Filter.BooleanOperation.OR.equals(cf.getOperation())) {
				List<Filter> filters = cf.getChildren();
				List<String> filterAttrs = new ArrayList<String>();
				if (filters != null) {
					for (Filter sf : filters) {
						if (sf instanceof Filter.LeafFilter) {
							String attr = ((Filter.LeafFilter) sf).getProperty();
							if (!filterAttrs.contains(attr)) {
								filterAttrs.add(attr);
							}
						} else {
							// Abort
							return false;
						}
					}
				}

				@SuppressWarnings("unchecked")
				List<String> authAttrs = this.getApplication().getListAttributeValue("authSearchAttributes");
				if (!filterAttrs.isEmpty()) {
					return equalStringLists(filterAttrs, authAttrs);
				}
			}
		}
		return false;
	}

	/**
	 * Get an iterator for the accounts or group objects based on the connector
	 * configuration and provided options.
	 *
	 * @param objectType
	 * @param filter
	 * @param options
	 * @return
	 * @throws ConnectorException
	 */
	public CloseableIterator<ResourceObject> iterateObjects(final String objectType, final Filter filter, final Map<String, Object> options) throws ConnectorException {
		if (masterConnector == null) {
			throw new ConnectorException("No master connector set");
		}
		if (log.isDebugEnabled()) {
			/*
			 * Debug code: check available schemas.
			 */
			log.debug(LogiPlexTools.stripControls(String.format("Enter: iterateObjects(%s, %s, %s)", objectType, filter, options)));
			Application masterApp = this.masterConnector.getApplication();
			log.debug(LogiPlexTools.stripControls(String.format("Application for master connector: %s", masterApp)));
			if (masterApp != null) {
				List<Schema> schemas = masterApp.getSchemas();
				if (schemas == null) {
					log.warn("No schemas");
				} else {
					for (Schema schema : schemas) {
						log.debug(LogiPlexTools.stripControls(String.format("Schema defined for %s", schema.getObjectType())));
					}
				}
			}
		}

		if (this.useCloudGateway && !this.useCloudGatewayLocal) {
			if (log.isInfoEnabled()) {
				log.info("Iterating via Cloud Gateway");
			}
			// In theory, this code should not be used if aggregated via the main application.
			return this.masterConnector.iterateObjects(objectType, filter, options);
		}
		if (this.useCloudGateway && this.useCloudGatewayLocal && log.isInfoEnabled()) {
			log.info("Iterating via Cloud Gateway, processing locally");
		}

		/*
		 * Call the corresponding method on the master connector. The iterator
		 * returned by the master connector will be used to read and process
		 * objects using the LogiPlexIterator.
		 */
		CloseableIterator<ResourceObject> masterIterator = this.masterConnector.iterateObjects(objectType, filter, options);
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Got master iterator: %s)", masterIterator)));
		}

		/*
		 * Check whether the filter provided is a filter for authentication.
		 */
		if ("account".equals(objectType) && isAuthenticationFilter(filter)) {
			if (log.isDebugEnabled()) {
				log.debug("This is an authentication/password reset request: using master iterator");
			}
			return masterIterator;
		}
		/*
		 * Proceed as usual
		 */
		CloseableIterator<ResourceObject> iterator = null;
		try {
			if (log.isDebugEnabled()) {
				log.debug("Getting LogiPlexIterator using master iterator");
			}
			iterator = new LogiPlexIterator<ResourceObject>(objectType, masterConnector, masterIterator, this.util, options);
		} catch (GeneralException e) {
			log.error(e);
			throw new ConnectorException(e);
		}
		if (log.isTraceEnabled()) {
			log.trace(LogiPlexTools.stripControls(String.format("Return iterator: %s", iterator)));
		}

		return iterator;
	}

	/**
	 * Get an iterator for partitioned aggregation.
	 *
	 * @param partition
	 * @return
	 * @throws ConnectorException
	 */
	@Override
	public CloseableIterator<ResourceObject> iterateObjects(Partition partition) throws ConnectorException {
		if (masterConnector == null) {
			throw new ConnectorException("No master connector set");
		}
		if (log.isDebugEnabled()) {
			/*
			 * Debug code: check available schemas.
			 */
			log.debug(LogiPlexTools.stripControls(String.format("Enter: iterateObjects(%s)", partition)));
			Application masterApp = this.masterConnector.getApplication();
			log.debug(LogiPlexTools.stripControls(String.format("Application for master connector: %s", masterApp)));
			if (masterApp != null) {
				List<Schema> schemas = masterApp.getSchemas();
				if (schemas == null) {
					log.warn("No schemas");
				} else {
					for (Schema schema : schemas) {
						log.debug(LogiPlexTools.stripControls(String.format("Schema defined for %s", schema.getObjectType())));
					}
				}
			}
		}
		/*
		 * Call the corresponding method on the master connector. The iterator
		 * returned by the master connector will be used to read and process
		 * objects using the LogiPlexIterator.
		 */
		CloseableIterator<ResourceObject> masterIterator = this.masterConnector.iterateObjects(partition);
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Got master iterator for partition: %s)", masterIterator)));
		}
		CloseableIterator<ResourceObject> iterator = null;
		try {
			if (log.isDebugEnabled()) {
				log.debug("Getting LogiPlexIterator for partition using master iterator");
			}
			iterator = new LogiPlexIterator<ResourceObject>(partition.getObjectType(), masterConnector, masterIterator, this.util, new HashMap<String, Object>());
		} catch (GeneralException e) {
			log.error(e);
			throw new ConnectorException(e);
		}
		if (log.isTraceEnabled()) {
			log.trace(LogiPlexTools.stripControls(String.format("Return partition iterator: %s", iterator)));
		}

		return iterator;
	}

	/**
	 * This methor will ask the master connector to generate a list of
	 * partitions.
	 *
	 * @param objectType
	 * @param suggestedPartitionCount
	 * @param filter
	 * @param ops
	 * @return
	 * @throws ConnectorException
	 */
	@Override
	public List<Partition> getIteratorPartitions(String objectType, int suggestedPartitionCount, Filter filter, Map<String, Object> ops) throws ConnectorException {
		if (this.useCloudGateway && !this.useCloudGatewayLocal) {
			throw new ConnectorException("Partitioning not supported via Cloud Gateway");
		}
		if (masterConnector == null) {
			throw new ConnectorException("No master connector set");
		}
		if (this.useCloudGateway && this.useCloudGatewayLocal) {
			/*
			 * When using Cloud Gateway, but not in the "classic" way.
			 *
			 * Get the main application, get the real connector and ask the real connector to produce the partitions
			 */
			try {
				Application mainApplication = LogiPlexTools.getMainApplication(context, getApplication());
				if (mainApplication == null) {
					throw new ConnectorException("Error getting main application");
				}
				String realConnectorName = mainApplication.getStringAttributeValue(LOGIPLEX_ATTR_MASTER_CONNECTOR);
				if (Util.isNullOrEmpty(realConnectorName)) {
					throw new ConnectorException("Error getting master connector name");
				}
				Connector realConnector = createConnector(realConnectorName, mainApplication, this.getInstance());
				if (realConnector == null) {
					throw new ConnectorException("Error instantiating master connector");
				}
				return realConnector.getIteratorPartitions(objectType, suggestedPartitionCount, filter, ops);
			} catch (GeneralException e) {
				log.error(LogiPlexTools.stripControls(String.format("Error getting partitions from main application: %s", e.getMessage())));
				throw new ConnectorException(e);
			}
		}
		/*
		 * Default: just ask the master connector to get the partitions.
		 */
		return masterConnector.getIteratorPartitions(objectType, suggestedPartitionCount, filter, ops);
	}

	/**
	 * Create a plan to remove all entitlements for a sub-application on the
	 * master if a request to delete a sub-application is encountered.
	 *
	 * @param link
	 * @param arguments
	 * @return
	 * @throws GeneralException
	 */
	public AccountRequest subAccountRemovalPlan(Link link, Attributes<String, Object> arguments) throws GeneralException {
		AccountRequest accountRequest = null;
		if (link != null) {
			Attributes<String, Object> attributes = link.getAttributes();
			if (attributes != null) {
				List<String> entitlementAttributes = LogiPlexTools.getAccountEntitlementAttributes(link.getApplication());
				Map<String, Object> entitlementValues = new HashMap<String, Object>();
				if (!entitlementAttributes.isEmpty()) {
					for (String entitlementAttribute : entitlementAttributes) {
						@SuppressWarnings("unchecked")
						List<String> values = (List<String>) attributes.get(entitlementAttribute);
						if (values != null) {
							entitlementValues.put(entitlementAttribute, values);
						}
					}
				}
				if (entitlementValues != null && !entitlementValues.isEmpty()) {
					accountRequest = new AccountRequest();
					accountRequest.setNativeIdentity(link.getNativeIdentity());
					accountRequest.setInstance(link.getInstance());
					accountRequest.setOperation(AccountRequest.Operation.Modify);
					accountRequest.setApplication(LogiPlexTools.getMainApplication(context, link.getApplication()).getName());
					accountRequest.setArguments(arguments);
					for (String name : entitlementValues.keySet()) {
						Object values = entitlementValues.get(name);
						if (values instanceof List) {
							@SuppressWarnings("unchecked")
							List<String> listValues = (List<String>) values;
							for (String value : listValues) {
								accountRequest.add(new AttributeRequest(name, ProvisioningPlan.Operation.Remove, value));
							}
						} else {
							accountRequest.add(new AttributeRequest(name, ProvisioningPlan.Operation.Remove, values));
						}
					}
					accountRequest.addArgument(ARG_ORIGINAL_TARGET_APP, link.getApplicationName());
				}
			}
		}
		return accountRequest;
	}

	/**
	 * Optimize the provisioning plan: make sure no duplicate create operations are left
	 * for the same application and native identity.
	 *
	 * @param plan
	 * @return
	 * @throws GeneralException
	 */
	public ProvisioningPlan optimizePlan(ProvisioningPlan plan) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: optimizePlan(%s)", plan)));
		}
		if (plan != null && !plan.isEmpty()) {
			List<AccountRequest> accountRequests = plan.getAccountRequests();
			List<AccountRequest> newAccountRequests = new ArrayList<AccountRequest>();
			if (accountRequests != null && !accountRequests.isEmpty()) {
				Map<String, Map<String, AccountRequest>> accountRequestMap = new HashMap<String, Map<String, AccountRequest>>();
				for (AccountRequest accountRequest : accountRequests) {
					if (AccountRequest.Operation.Create.equals(accountRequest.getOperation())) {
						if (log.isTraceEnabled()) {
							log.trace(LogiPlexTools.stripControls(String.format("Inspecting account Create request: %s", accountRequest)));
						}
						String applicationName = accountRequest.getApplication();
						String nativeIdentity = accountRequest.getNativeIdentity();
						Map<String, AccountRequest> map = accountRequestMap.get(applicationName);
						if (map == null) {
							map = new HashMap<String, AccountRequest>();
						}
						AccountRequest ar = map.get(nativeIdentity);
						if (ar != null) {
							if (log.isTraceEnabled()) {
								log.trace(LogiPlexTools.stripControls(
										String.format("Found second Create request. Turing account request into Modify: %s", (accountRequest == null) ? "NULL" : accountRequest.toXml())));
							}
							AccountRequest mar = (AccountRequest) accountRequest.deepCopy(context);
							mar.setOperation(AccountRequest.Operation.Modify);
							mar = stripNonEntitlementChanges(mar);
							newAccountRequests.add(mar);
							// Merge Create requests.
							// ar = mergeAccountRequests(ar, accountRequest);
							// if (log.isTraceEnabled()) {
							// log.trace(LogiPlexTools.stripControls(String.format("Merged account request: %s",
							// (accountRequest==null)?"NULL":accountRequest.toXml())));
							// }
							map.put(nativeIdentity, ar);
						} else {
							map.put(nativeIdentity, accountRequest);
						}
						accountRequestMap.put(applicationName, map);
					} else {
						newAccountRequests.add(accountRequest);
					}
				}

				// Clear out the list of account requests
				plan.setAccountRequests(new ArrayList<AccountRequest>());
				// Re-add account requests, Create operations first.
				if (accountRequestMap != null && !accountRequestMap.isEmpty()) {
					for (String appName : accountRequestMap.keySet()) {
						Map<String, AccountRequest> map = accountRequestMap.get(appName);
						if (map != null && !map.isEmpty()) {
							for (String ni : map.keySet()) {
								AccountRequest ar = map.get(ni);
								// Add if the request is not null and if it is Create/Modify, it must have Attribute Requests in order to be added.
								if (ar != null && ((ar.getAttributeRequests() != null && ar.getAttributeRequests().size() > 0)
										|| (!AccountRequest.Operation.Modify.equals(ar.getOperation()) && !AccountRequest.Operation.Create.equals(ar.getOperation())))) {
									plan.add(ar);
								}
							}
						}
					}
				}
				if (newAccountRequests != null && !newAccountRequests.isEmpty()) {
					for (AccountRequest ar : newAccountRequests) {
						plan.add(ar);
					}
				}
			}
		}
		if (log.isTraceEnabled() && plan != null) {
			log.trace(LogiPlexTools.stripControls(String.format("Optimized plan: %s", plan.toXml())));
		}
		return plan;
	}

	/**
	 * Apply default logic to transform the plans for sub-applications into
	 * information for the main application. The default logic will ignore
	 * attribute changes, other than entitlements for sub-application.
	 *
	 * When operations are processed for the master application, they may need
	 * to be applied to the sub-applications, too.
	 *
	 * @param plan
	 *            The ProvisioningPlan object to be inspected and modified.
	 * @param originalPlan
	 * @param identity
	 *            The identity for which the plan is to be executed.
	 * @return A modified ProvisioningPlan object.
	 * @throws GeneralException
	 */
	public ProvisioningPlan runDefaultProvisioningMergeLogic(ProvisioningPlan plan, ProvisioningPlan originalPlan, Identity identity) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: runDefaultProvisioningMergeLogic(%s, %s, %s)", plan, originalPlan, identity)));
		}
		return runDefaultProvisioningMergeLogic(plan, originalPlan, identity, false, null);
	}

	/**
	 * Apply default logic to transform the plans for sub-applications into
	 * information for the main application. The default logic will ignore
	 * attribute changes, other than entitlements for sub-application.
	 *
	 * When operations are processed for the master application, they may need
	 * to be applied to the sub-applications, too.
	 *
	 * @param plan
	 *            The ProvisioningPlan object to be inspected and modified.
	 * @param originalPlan
	 * @param identity
	 *            The identity for which the plan is to be executed.
	 * @param useGetObject
	 *            If true and the master connector is set, try to get the object from the source using getObject to verify existence.
	 * @param masterConnector
	 *            The master connector.
	 * @return A modified ProvisioningPlan object.
	 * @throws GeneralException
	 */
	public ProvisioningPlan runDefaultProvisioningMergeLogic(ProvisioningPlan plan, ProvisioningPlan originalPlan, Identity identity, boolean useGetObject, Connector masterConnector)
			throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: runDefaultProvisioningMergeLogic(%s, %s, %s, %b, %s)", plan, originalPlan, identity, useGetObject, masterConnector)));
		}
		if (plan != null && (identity != null || (plan.getObjectRequests() != null && !plan.getObjectRequests().isEmpty()))) {
			ProvisioningPlan newPlan = new ProvisioningPlan();
			newPlan.setNativeIdentity(plan.getNativeIdentity());
			newPlan.setArguments(plan.getArguments());

			List<AccountRequest> accountRequests = plan.getAccountRequests();
			if (accountRequests != null && !accountRequests.isEmpty()) {
				for (AccountRequest accountRequest : accountRequests) {
					if (log.isTraceEnabled() && accountRequest != null) {
						log.trace(accountRequest.toXml());
						log.trace(String.format("Operation: %s", accountRequest.getOperation().toString()));
					}
					boolean isMainApplicationRequest = LogiPlexTools.isMainApplicationRequest(this.context, this.getApplication(), accountRequest);
					switch (accountRequest.getOperation()) {
					case Create:
						Link mainLink = LogiPlexTools.getMainLink(context, identity, this.getApplication(), accountRequest, useGetObject, masterConnector);
						if (isMainApplicationRequest || mainLink == null) {
							if (log.isTraceEnabled()) {
								log.trace(String.format("MainLink: %s", ((mainLink == null) ? "NULL" : mainLink.toXml())));
							}
							if (!isMainApplicationRequest) {
								if (log.isTraceEnabled()) {
									log.trace("Sub-application request, creating new account request");
								}
								// ...meaning mainLink is null
								AccountRequest newAccountRequest = (AccountRequest) accountRequest.deepCopy(this.context);
								Application mainApplication = LogiPlexTools.getMainApplication(context, getApplication());
								newAccountRequest.setApplication(mainApplication.getName());
								if (log.isTraceEnabled()) {
									log.trace(LogiPlexTools.stripControls(String.format("New account request: %s", newAccountRequest.toXml())));
								}
								newPlan.add(newAccountRequest);
							} else {
								if (log.isTraceEnabled()) {
									log.trace("Main application request, copying account request");
								}
								newPlan.add((AccountRequest) accountRequest.deepCopy(context));
							}
						} else {
							if (log.isTraceEnabled()) {
								log.trace("Sub-application request with existing main account.");
							}
							// Just add the entitlements
							List<AttributeRequest> atrqs = new ArrayList<AttributeRequest>();

							List<String> entitlementAttributes = LogiPlexTools.getAccountEntitlementAttributes(this.getApplication());
							for (String entitlementAttribute : entitlementAttributes) {
								List<AttributeRequest> eatrqs = accountRequest.getAttributeRequests(entitlementAttribute);
								if (eatrqs != null && !eatrqs.isEmpty()) {
									atrqs.addAll(eatrqs);
								}
							}

							// Create a new list and copy modified versions of
							// each attribute request into the list.
							List<AttributeRequest> newAtrqs = new ArrayList<AttributeRequest>();
							if (atrqs != null && !atrqs.isEmpty()) {
								for (AttributeRequest atrq : atrqs) {
									if (ProvisioningPlan.Operation.Set.equals(atrq.getOperation()) || ProvisioningPlan.Operation.Add.equals(atrq.getOperation())) {
										atrq.setOperation(ProvisioningPlan.Operation.Add);
										newAtrqs.add((AttributeRequest) atrq.deepCopy(context));
									}
								}
							}
							if (!newAtrqs.isEmpty()) {
								if (log.isTraceEnabled()) {
									log.trace("Creating account request for sub-application with existing main account.");
								}
								AccountRequest nar = new AccountRequest();
								nar.setNativeIdentity(mainLink.getNativeIdentity());
								nar.setInstance(accountRequest.getInstance());
								nar.setOperation(AccountRequest.Operation.Modify);
								nar.setApplication(LogiPlexTools.getMainApplication(context, this.getApplication()).getName());
								nar.setArguments(accountRequest.getArguments());
								nar.setAttributeRequests(newAtrqs);
								if (log.isTraceEnabled()) {
									log.trace(LogiPlexTools.stripControls(String.format("Sub-application account request: %s", nar.toXml())));
								}
								newPlan.add(nar);
							}

							// In case of "Create" operation we need to remove
							// attributes that are not passed to master
							// application connector
							// Current account state may be different from what
							// has been requested in "Create" request, e.g.
							// ProvisioningPolicy says that
							// new account should be disabled, but existing AD
							// account is enabled. In such case AccessRequest
							// will never be verified

							if (originalPlan != null && !originalPlan.equals(plan)) {
								List<String> mainAppEntitlementAttributes = LogiPlexTools.getAccountEntitlementAttributes(masterApplication);
								AccountRequest matchingAccountRequest = LogiPlexTools.getMatchingAccountRequest(originalPlan, accountRequest);
								if (matchingAccountRequest != null && !Util.isEmpty(mainAppEntitlementAttributes)) {
									List<AttributeRequest> attributeRequests = matchingAccountRequest.getAttributeRequests();
									if (!Util.isEmpty(attributeRequests)) {
										Iterator<AttributeRequest> attributeRequestIterator = attributeRequests.iterator();
										while (attributeRequestIterator.hasNext()) {
											AttributeRequest attributeRequest = attributeRequestIterator.next();
											if (attributeRequest != null) {
												if (!mainAppEntitlementAttributes.contains(attributeRequest.getName())) {
													attributeRequestIterator.remove();
												}
											}
										}
									}
								}
							}
						}
						break;
					case Enable:
					case Disable:
					case Lock:
					case Unlock:
						// Only handle Enable/Disable/Lock/Unlock for the main
						// application,
						// not for any sub-application.
						if (isMainApplicationRequest) {
							newPlan.add(((AccountRequest) accountRequest.deepCopy(context)));
						} else {
							// Check whether sub-application account request has any attribute changes.
							// If so, turn it into a modify operation and add that to the plan.
							List<AttributeRequest> attributeRequests = accountRequest.getAttributeRequests();
							if (attributeRequests != null && !attributeRequests.isEmpty()) {
								AccountRequest modifyAccountRequest = (AccountRequest) accountRequest.deepCopy(context);
								modifyAccountRequest.setOperation(AccountRequest.Operation.Modify);
								newPlan.add(modifyAccountRequest);
							}
						}
						break;
					case Modify:
						if (isMainApplicationRequest) {
							newPlan.add(((AccountRequest) accountRequest.deepCopy(context)));
						} else {
							// For modification of a sub-application, we have to
							// carefully figure out what to do.
							// We need to compare the requested change to the
							// current state.
							Link link = LogiPlexTools.getLink(context, identity, accountRequest);
							if (link != null) {
								List<AttributeRequest> atrqs = new ArrayList<AttributeRequest>();
								List<String> entitlementAttributes = LogiPlexTools.getAccountEntitlementAttributes(this.getApplication());
								for (String entitlementAttribute : entitlementAttributes) {
									List<AttributeRequest> eatrqs = accountRequest.getAttributeRequests(entitlementAttribute);
									if (eatrqs != null && !eatrqs.isEmpty()) {
										atrqs.addAll(eatrqs);
									}
								}
								List<AttributeRequest> newAtrqs = new ArrayList<AttributeRequest>();
								if (atrqs != null && !atrqs.isEmpty()) {
									for (AttributeRequest atrq : atrqs) {
										// Only handle entitlement attributes.
										String attributeName = atrq.getName();
										if (LogiPlexTools.isAccountEntitlementAttribute(this.getApplication(), attributeName)) {
											if (ProvisioningPlan.Operation.Set.equals(atrq.getOperation())) {
												if (LogiPlexTools.isMultiValuedAccountAttribute(this.getApplication(), attributeName)) {
													Attributes<String, Object> attributes = link.getAttributes();
													if (attributes != null && !attributes.isEmpty()) {
														@SuppressWarnings("unchecked")
														List<String> oldValues = (List<String>) attributes.getList(attributeName);
														List<String> newValues = new ArrayList<String>();
														Object value = atrq.getValue();
														if (value instanceof List) {
															@SuppressWarnings("unchecked")
															List<String> listValue = (List<String>) value;
															newValues.addAll(listValue);
														} else if (value != null) {
															newValues.add(value.toString());
														}

														@SuppressWarnings("unchecked")
														List<String> toAdd = (List<String>) LogiPlexTools.getItemsToAdd(oldValues, newValues);
														@SuppressWarnings("unchecked")
														List<String> toRemove = (List<String>) LogiPlexTools.getItemsToRemove(oldValues, newValues);
														for (String val : toRemove) {
															newAtrqs.add(new AttributeRequest(attributeName, ProvisioningPlan.Operation.Remove, val));
														}
														for (String val : toAdd) {
															newAtrqs.add(new AttributeRequest(attributeName, ProvisioningPlan.Operation.Add, val));
														}
													}
												} else {
													newAtrqs.add(atrq);
												}
											} else {
												newAtrqs.add(atrq);
											}
										}
									}
									if (!newAtrqs.isEmpty()) {
										AccountRequest nar = new AccountRequest();
										nar.setNativeIdentity(accountRequest.getNativeIdentity());
										nar.setInstance(accountRequest.getInstance());
										nar.setOperation(AccountRequest.Operation.Modify);
										nar.setApplication(LogiPlexTools.getMainApplication(context, this.getApplication()).getName());
										nar.setArguments(accountRequest.getArguments());
										nar.setAttributeRequests(newAtrqs);
										newPlan.add(nar);
									}
								}
							}
						}
						break;
					case Delete:
						if (isMainApplicationRequest) {
							// Add only main account, sub-accounts will be deleted as well
							newPlan.add(accountRequest);
						} else {
							// For deletion of a sub-application, we remove all
							// values for entitlements.
							Link link = LogiPlexTools.getLink(context, identity, accountRequest);
							AccountRequest nar = subAccountRemovalPlan(link, accountRequest.getArguments());
							if (nar != null) {
								newPlan.add(nar);
							}
						}
						break;
					default:
						break;
					}
				}
			}

			List<ObjectRequest> objectRequests = plan.getObjectRequests();
			if (objectRequests != null && !objectRequests.isEmpty()) {
				if (log.isDebugEnabled()) {
					log.debug("Handling object requests.");
				}
				for (ObjectRequest objectRequest : objectRequests) {
					if (log.isTraceEnabled() && objectRequest != null) {
						log.trace(objectRequest.toXml());
						log.trace(String.format("Operation: %s", objectRequest.getOp().toString()));
					}
					boolean isMainApplicationRequest = LogiPlexTools.isMainApplicationRequest(this.context, this.getApplication(), objectRequest);
					if (!isMainApplicationRequest) {
						ObjectRequest newObjectRequest = (ObjectRequest) objectRequest.deepCopy(this.context);
						Application mainApplication = LogiPlexTools.getMainApplication(this.context, getApplication());
						newObjectRequest.setApplication(mainApplication.getName());
						newPlan.add(newObjectRequest);
					} else {
						newPlan.add(objectRequest);
					}
				}
			}

			newPlan = optimizePlan(newPlan);
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("New plan:\n%s", newPlan.toXml())));
			}
			return newPlan;
		}
		return plan;

	}

	/**
	 * Find and run the LogiPlex Provisioning Rule, if set. Otherwise, use the
	 * default logic.
	 *
	 * @param plan
	 *            The ProvisioningPlan object to be inspected and modified.
	 * @return A modified ProvisioningPlan object.
	 * @throws ConnectorException
	 * @throws GeneralException
	 */
	private ProvisioningPlan runProvisioningMergeRule(ProvisioningPlan plan, ProvisioningPlan originalPlan) throws ConnectorException, GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: runProvisioningMergeRule(%s)", plan)));
		}
		String ruleName = this.getApplication().getStringAttributeValue(LOGIPLEX_PROVISIONING_RULE);
		Rule rule = null;

		// If configured, try to retrieve the rule.
		if (Util.isNotNullOrEmpty(ruleName)) {
			log.debug("Looking up provisioning rule: " + ruleName);
			rule = context.getObjectByName(Rule.class, ruleName);
			if (rule == null) {
				throw new ConnectorException(LogiPlexTools.stripControls(String.format("Rule %s not found", ruleName)));
			}
		} else {
			if (log.isInfoEnabled()) {
				log.info("No rule configured, use default logic");
			}
		}

		// Determine identity from plan
		Identity identity = getIdentityFromPlan(plan);
		List<AccountRequest> accountRequests = plan.getAccountRequests();

		if (identity == null && accountRequests != null && !accountRequests.isEmpty()) {
			log.warn("Could not get identity from the plan. Identity will be set to null in rule arguments");
		}

		if (rule != null) {
			Map<String, Object> args = new HashMap<String, Object>();
			args.put("context", context);
			args.put("log", log);
			args.put("plan", plan);
			args.put("originalPlan", originalPlan);
			args.put("identity", identity);
			args.put("application", this.getApplication());
			args.put("masterApplication", this.masterApplication);
			args.put("connector", this);
			args.put("masterConnector", this.masterConnector);
			log.debug(LogiPlexTools.stripControls(String.format("Running provisioning rule %s with arguments %s", ruleName, args.toString())));
			Object result = context.runRule(rule, args);
			if (result instanceof ProvisioningPlan) {
				if (log.isTraceEnabled()) {
					log.trace(LogiPlexTools.stripControls(String.format("Modified plan: %s", ((ProvisioningPlan) result).toXml())));
				}
				plan = (ProvisioningPlan) result;
			} else if (result != null) {
				throw new GeneralException(LogiPlexTools.stripControls(String.format("Incorrect result type %s from provisioning rule", result.getClass().getName())));
			}
		} else {
			boolean defaultUseGetObject = !(masterApplication.supportsFeature(Feature.NO_AGGREGATION) || masterApplication.supportsFeature(Feature.NO_RANDOM_ACCESS));
			boolean useGetObject = this.getBooleanArgument(LOGIPLEX_ATTR_PROVISION_GET_OBJECT, defaultUseGetObject);
			plan = runDefaultProvisioningMergeLogic(plan, originalPlan, identity, useGetObject, this.masterConnector);
		}
		if (log.isTraceEnabled()) {
			log.trace(String.format("Exit: runProvisioningMergeRule(): %s", (plan == null) ? "NULL" : plan.toXml()));
		}
		return plan;
	}

	private List<String> getSubApplicationNames(Application application) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: getSubApplicationNames(%s)", application)));
		}

		if (subApplicationNames == null) {
			subApplicationNames = LogiPlexTools.getSubApplicationNames(context, application);
		}
		return subApplicationNames;
	}

	/**
	 * Remove any entitlement changes that belong to a sub application request from the generated request for the
	 * main application.
	 *
	 * @param mainRequest
	 * @param subRequest
	 * @return
	 * @throws GeneralException
	 */
	private AccountRequest stripEntitlementChanges(AccountRequest mainRequest, AccountRequest subRequest) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: stripEntitlementChanges(%s, %s)", mainRequest, subRequest)));
		}
		if (log.isTraceEnabled()) {
			log.trace(LogiPlexTools.stripControls(String.format("Main Request:\n%s\n\nSub Request:\n%s\n", mainRequest, subRequest)));
		}
		if (mainRequest != null) {
			if (subRequest == null) {
				return mainRequest;
			}

			Application application = mainRequest.getApplication(context);
			if (application != null) {
				Schema schema = application.getAccountSchema();
				if (schema != null) {
					List<String> entitlementNames = schema.getEntitlementAttributeNames();
					if (entitlementNames != null && !entitlementNames.isEmpty()) {
						for (String name : entitlementNames) {
							if (subRequest.getAttributeRequests(name) != null) {
								List<AttributeRequest> attributeRequests = new ArrayList<AttributeRequest>();
								attributeRequests.addAll(mainRequest.getAttributeRequests(name));
								for (AttributeRequest attributeRequest : attributeRequests) {
									mainRequest.remove(attributeRequest);
								}
							}
						}
					}
				}
				return mainRequest;
			}
		}
		return null;
	}

	/**
	 *
	 * @param accountRequest
	 * @return
	 * @throws GeneralException
	 */
	private AccountRequest stripNonEntitlementChanges(AccountRequest accountRequest) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: stripNonEntitlementChanges(%s)", accountRequest)));
		}
		if (accountRequest != null) {
			AccountRequest newAccountRequest = (AccountRequest) accountRequest.deepCopy(context);
			newAccountRequest.setAttributeRequests(new ArrayList<AttributeRequest>());
			Application application = accountRequest.getApplication(context);
			if (application != null) {
				Schema schema = application.getAccountSchema();
				if (schema != null) {
					List<String> entitlementNames = schema.getEntitlementAttributeNames();
					if (entitlementNames != null && !entitlementNames.isEmpty()) {
						for (String entitlementName : entitlementNames) {
							List<AttributeRequest> attributeRequests = accountRequest.getAttributeRequests(entitlementName);
							if (attributeRequests != null && !attributeRequests.isEmpty()) {
								for (AttributeRequest attributeRequest : attributeRequests) {
									newAccountRequest.add((AttributeRequest) attributeRequest.deepCopy(context));
								}
							}
						}
					}
				}
				return newAccountRequest;
			}
		}
		return null;
	}

	/**
	 * Process the provisioned plan, re-aggregate accounts and apply the resource object to the results.
	 *
	 * @param originalPlan
	 * @param plan
	 * @param masterResult
	 * @throws ConnectorException
	 * @throws GeneralException
	 */
	private void postProvisionUpdatePlanUsingAggregation(ProvisioningPlan originalPlan, ProvisioningResult masterResult) throws ConnectorException, GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: postProvisionUpdatePlanUsingAggregation(%s, %s)", originalPlan, masterResult)));
		}
		if (originalPlan != null) {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Original Plan: %s", originalPlan.toXml())));
				log.trace(LogiPlexTools.stripControls(String.format("Master Result: %s", (masterResult == null) ? "NULL" : masterResult.toXml())));
			}
			boolean defaultUseGetObject = !(masterApplication.supportsFeature(Feature.NO_AGGREGATION) || masterApplication.supportsFeature(Feature.NO_RANDOM_ACCESS));
			boolean useGetObject = this.getBooleanArgument(LOGIPLEX_ATTR_PROVISION_GET_OBJECT, defaultUseGetObject);
			if (useGetObject) {
				int delay = getIntegerArgument(LOGIPLEX_ATTR_RE_AGGREGATE_DELAY);
				if (delay > 0) {
					try {
						if (log.isDebugEnabled()) {
							log.debug(LogiPlexTools.stripControls(String.format("Delaying re-aggregation by %d seconds.", delay)));
						}
						Thread.sleep(delay * 1000L);
					} catch (InterruptedException e) {
						log.error(LogiPlexTools.stripControls(String.format("Error trying to sleep: %s", e.getMessage())));
					}
				}
				List<AccountRequest> accountRequests = originalPlan.getAccountRequests();
				List<ObjectRequest> objectRequests = originalPlan.getObjectRequests();
				Map<String, String> planNativeIdentitiesMap = handleActiveDirectoryAccountMoveAndRename(originalPlan);

				// We should be able to read back the account
				// information
				if (accountRequests != null && !accountRequests.isEmpty()) {
					// Accounts
					for (AccountRequest accountRequest : accountRequests) {
						String nativeIdentity = accountRequest.getNativeIdentity();
						if (!Util.isEmpty(planNativeIdentitiesMap)) {
							String newNativeIdentity = planNativeIdentitiesMap.get(nativeIdentity);
							if (!Util.isEmpty(newNativeIdentity)) {
								nativeIdentity = newNativeIdentity;
							}
						}
						ProvisioningResult subResult = accountRequest.getResult();
						if (subResult == null) {
							subResult = new ProvisioningResult();
							subResult.setStatus(masterResult.getStatus());
							accountRequest.setResult(subResult);
						}
						if (log.isTraceEnabled()) {
							log.trace(LogiPlexTools.stripControls(String.format("Account Request: %s", accountRequest.toXml())));
							log.trace(LogiPlexTools.stripControls(String.format("Sub-Result: %s", subResult.toXml())));
						}
						if (subResult.isCommitted()) {
							if (!AccountRequest.Operation.Delete.equals(accountRequest.getOperation())) {
								try {
									ResourceObject object = subResult.getObject();
									if (Util.isNullOrEmpty(nativeIdentity) && object != null) {
										nativeIdentity = object.getIdentity();
									}
									if (Util.isNotNullOrEmpty(nativeIdentity)) {
										if (Util.isNullOrEmpty(accountRequest.getNativeIdentity())) {
											// This may happen during account creation if the target system generates the native identity.
											accountRequest.setNativeIdentity(nativeIdentity);
										}
										object = masterConnector.getObject("account", nativeIdentity, new HashMap<String, Object>());
										Map<String, ResourceObject> splitObjects = util.splitResourceObject(object);
										String orginalTarget = (String) accountRequest.getArgument(ARG_ORIGINAL_TARGET_APP);
										String currentTarget = accountRequest.getApplication();
										log.debug(LogiPlexTools.stripControls(String.format("Original target application: %s; Current target application: %s.", orginalTarget, currentTarget)));
										if (Util.isNullOrEmpty(orginalTarget)) {
											orginalTarget = accountRequest.getApplication();
										}
										ResourceObject resultObject = splitObjects.get(currentTarget);
										if (resultObject != null) {
											if (log.isTraceEnabled()) {
												log.trace(LogiPlexTools.stripControls(
														String.format("Retrieved ResourceObject for account %s on %s: %s", nativeIdentity, currentTarget, resultObject.toXml())));
											}
											subResult.setObject(resultObject);
										}
									} else {
										log.warn("Unknown native identity - not getting object using getObject");
									}
								} catch (Exception e) {
									log.error(LogiPlexTools.stripControls(String.format("Error while reading back account: %s", ExceptionUtils.getFullStackTrace(e))));
									subResult.addError(e);
								}
							} else {
								// No action for Delete operations.
							}
						}

						// LogiPlexTools.updateResultsInOriginalPlan(originalPlan, accountRequest);
					}
				} else if (objectRequests != null && !objectRequests.isEmpty()) {
					// Groups
					/*
					ObjectRequest objectRequest = plan.getObjectRequests().get(0);
					String nativeIdentity = objectRequest.getNativeIdentity();
					String objectType = objectRequest.getType();
					*/
					// TODO: Aggregate back
				}
			}
		}
	}
	
	/**
	 * Remove any empty modify requests. These could be left-overs from moving items back and forth.
	 * 
	 * @param originalPlan
	 */
	private void postProvisioningFilterPlan(ProvisioningPlan originalPlan) {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: postProvisioningFilterPlan(%s)", originalPlan)));
		}
		if (originalPlan != null) {
			// Check for empty account requests
			List<AccountRequest> accountRequests = originalPlan.getAccountRequests();
			List<AccountRequest> filteredAccountRequests = new ArrayList<AccountRequest>();
			if (accountRequests != null && !accountRequests.isEmpty())  {
				for (AccountRequest accountRequest: accountRequests) {
					List<AttributeRequest> attributeRequest = accountRequest.getAttributeRequests();
					if (!(AccountRequest.Operation.Modify.equals(accountRequest.getOperation()) && (attributeRequest == null || attributeRequest.isEmpty()))) {
						filteredAccountRequests.add(accountRequest);	
					}
				}
				originalPlan.setAccountRequests(filteredAccountRequests);
			}

			List<ObjectRequest> objectRequests = originalPlan.getObjectRequests();
			List<ObjectRequest> filteredObjectRequests = new ArrayList<ObjectRequest>();
			if (objectRequests != null && !objectRequests.isEmpty())  {
				for (ObjectRequest objectRequest: objectRequests) {
					List<AttributeRequest> attributeRequest = objectRequest.getAttributeRequests();
					if (!(ObjectOperation.Modify.equals(objectRequest.getOp()) && (attributeRequest == null || attributeRequest.isEmpty()))) {						
						filteredObjectRequests.add(objectRequest);	
					}
				}
				originalPlan.setObjectRequests(filteredObjectRequests);
			}

		}
	}

	/**
	 * Create a mapping table for name changes in Active Directory.
	 * 
	 * @param originalPlan
	 * @return
	 * @throws GeneralException
	 */
    private Map<String, String> handleActiveDirectoryAccountMoveAndRename(ProvisioningPlan originalPlan) throws GeneralException {
        Map<String, String> planNativeIdentitiesMap = new HashMap<>();
        if(originalPlan == null) {
            return planNativeIdentitiesMap;
        }
        //build a Map where:
        //key: initial account request nativeIdentity
        //value: updated nativeIdentity, e.g. due to account move or rename
        //we check all accountRequest in the plan to handle scenario where there are multiple account requests for single account
        if (Util.nullSafeEq(getMasterApplicationTargetConnector(), ADLDAP_CONNECTOR_CLASS)) {
            planNativeIdentitiesMap = buildPlanNativeIdentitiesMap(originalPlan);
        }
        return planNativeIdentitiesMap;
    }

    /**
     * Get the target connector from the master application.
     * 
     * @return
     */
    private String getMasterApplicationTargetConnector() {
        if (masterApplication == null) {
            return null;
        }

        return masterApplication.getStringAttributeValue(LOGIPLEX_ATTR_MASTER_CONNECTOR);
    }

    /**
	 * Create a mapping table for name changes in Active Directory.
     * 
     * @param plan
     * @return
     * @throws GeneralException
     */
    private Map<String, String> buildPlanNativeIdentitiesMap(ProvisioningPlan plan) throws GeneralException {
        Map<String, String> returnMap = new HashMap<>();
        if (plan == null) {
            log.debug("ProvisioningPlan is empty");
            return returnMap;
        }
        List<AccountRequest> accountRequests = plan.getAccountRequests();
        if (Util.isEmpty(accountRequests)) {
            log.debug("There are no AccountRequest objects in the plan");
            return returnMap;
        }

        if (log.isDebugEnabled()) {
            log.debug(LogiPlexTools.stripControls(String.format("Building updated native identities map for plan: %s", plan.toXml())));
        }

    	Schema schema = getApplication().getAccountSchema();
    	if (schema == null) {
    		throw new GeneralException(String.format("buildPlanNativeIdentitiesMap: application %s does not have an account schema.", getApplication().getName()));        		
    	}
    	String identityAttribute = schema.getIdentityAttribute();
    	if ("dn".equalsIgnoreCase(identityAttribute) || "distinguishedName".equalsIgnoreCase(identityAttribute)) {
	        for (AccountRequest accountRequest : Util.safeIterable(accountRequests)) {        	
	            if (accountRequest.getResult() != null && accountRequest.getResult().isCommitted()) {
	                List<AttributeRequest> attributeRequests = accountRequest.getAttributeRequests();
	                for (AttributeRequest attributeRequest : Util.safeIterable(attributeRequests)) {
	                    try {
	                        String initialNativeIdentity = accountRequest.getNativeIdentity();
	                        String nativeIdentityToUpdate;
	                        String updatedNativeIdentity = returnMap.get(initialNativeIdentity);
	                        if (!Util.isEmpty(updatedNativeIdentity)) {
	                            nativeIdentityToUpdate = updatedNativeIdentity;
	                        } else {
	                            nativeIdentityToUpdate = initialNativeIdentity;
	                        }
	
	                        String attributeRequestName = attributeRequest.getName();
	                        if (Util.nullSafeCaseInsensitiveEq(attributeRequestName, "AC_newParent")) {
	                            String newOU = (String) attributeRequest.getValue();
	                            LdapName ldapName = new LdapName(nativeIdentityToUpdate);
	                            String cn = ldapName.get(ldapName.size() - 1);
	                            LdapName newLdapName = new LdapName(newOU);
	                            newLdapName.add(newLdapName.size(), cn);
	                            returnMap.put(initialNativeIdentity, newLdapName.toString());
	
	                        } else if (Util.nullSafeCaseInsensitiveEq(attributeRequestName, "AC_newName")) {
	                            String newCN = (String) attributeRequest.getValue();
	                            LdapName ldapName = new LdapName(nativeIdentityToUpdate);
	                            ldapName.remove(ldapName.size() - 1);
	                            ldapName.add(ldapName.size(), newCN);
	                            returnMap.put(initialNativeIdentity, ldapName.toString());
	                        }
	                    } catch (InvalidNameException e) {
	                        throw new GeneralException("Error during DN parsing", e);
	                    }
	                }
	            }
	        }
    	} else {
    		if (log.isInfoEnabled()) {
    			log.info("Identity attribute is not a distinguishedName - skipping check");
    		}
    	}
        if (log.isDebugEnabled()) {
            log.debug(LogiPlexTools.stripControls(String.format("Updated native identities map is: %s", returnMap)));
        }
        return returnMap;
    }

	/**
	 * Try to extract the identity from the plan.
	 * First, the identity object from the plan,
	 * Second embedded by a Before Provisioning Rule,
	 * Third by name from the context.
	 *
	 * @param plan
	 * @return
	 * @throws GeneralException
	 */
	private Identity getIdentityFromPlan(ProvisioningPlan plan) throws GeneralException {
		if (plan != null) {
			Identity identity = plan.getIdentity();
			if (identity != null) {
				return identity;
			}
			Attributes<String, Object> args = plan.getArguments();
			if (args != null && !args.isEmpty()) {
				String encodedXml = args.getString(ARG_LOGIPLEX_PLAN_IDENTITY);
				if (Util.isNotNullOrEmpty(encodedXml)) {
					String xml = new String(Base64.getDecoder().decode(encodedXml.getBytes()));
					identity = (Identity) AbstractXmlObject.parseXml(context, xml);
				}
				args.remove(ARG_LOGIPLEX_PLAN_IDENTITY);
			}
			if (identity != null) {
				return identity;
			}
			String identityName = plan.getNativeIdentity();
			if (Util.isNotNullOrEmpty(identityName)) {
				identity = context.getObjectByName(Identity.class, identityName);
				return identity;
			}
		}
		return null;
	}

	@Override
	public ProvisioningResult provision(ProvisioningPlan originalPlan) throws ConnectorException {
		if (originalPlan != null) {
			if (log.isDebugEnabled()) {
				log.debug(LogiPlexTools.stripControls(String.format("Enter: provision(%s)", originalPlan)));
			}
			if (log.isTraceEnabled() && originalPlan != null) {
				try {
					log.trace(LogiPlexTools.stripControls(String.format("Provisioning plan: %s", originalPlan.toXml())));
				} catch (GeneralException e) {
					log.error(e);
				}
			}
			if (masterConnector == null) {
				throw new ConnectorException("No master connector set");
			}
			if (this.useCloudGateway && !this.useCloudGatewayLocal && CIB_CONNECTOR_CLASS.equals(masterConnector.getClass().getName())) {
				/*
				 * Using cloud gateway via main application's proxy setting.
				 */
				if (log.isInfoEnabled()) {
					log.info(String.format("Using Cloud Gateway connector %s", masterConnector.getApplication().getName()));
				}
				try {
					return masterConnector.provision(originalPlan);
				} catch (GeneralException e) {
					log.error("Error provisioning through Cloud Gateway", e);
					throw new ConnectorException(e);
				}
			}
			if (masterApplication == null) {
				throw new ConnectorException("No master application set");
			}

			try {
				boolean simulate = this.getBooleanArgument(LOGIPLEX_ATTR_SIMULATE_PROVISIONING, false);
				LogiPlexTools.setTrackingIDOnOriginalPlan(originalPlan);
				// Clone original plan
				ProvisioningPlan plan = (ProvisioningPlan) originalPlan.deepCopy(context);
				List<AccountRequest> accountRequests = plan.getAccountRequests();
				List<ObjectRequest> objectRequests = plan.getObjectRequests();

				// Store the original target application for later use
				if (accountRequests != null && !accountRequests.isEmpty()) {
					for (AccountRequest accountRequest : accountRequests) {
						accountRequest.put(ARG_ORIGINAL_TARGET_APP, accountRequest.getApplication());
					}
				}
				if (objectRequests != null && !objectRequests.isEmpty()) {
					for (ObjectRequest objectRequest : objectRequests) {
						objectRequest.put(ARG_ORIGINAL_TARGET_APP, objectRequest.getApplication());
					}
				}

				// Process Plan
				plan = runProvisioningMergeRule(plan, originalPlan);

				// Provision through master connector.
				if (plan != null && ((plan.getAccountRequests() != null && !plan.getAccountRequests().isEmpty()) || (plan.getObjectRequests() != null && !plan.getObjectRequests().isEmpty()))) {
					ProvisioningResult masterResult;
					if (simulate) {
						if (log.isInfoEnabled()) {
							log.info("Simulated Provisioning - Not doing provisioning to actual connector");
						}
						masterResult = new ProvisioningResult();
						String simResult = this.getStringArgument(LOGIPLEX_ATTR_SIMULATE_PROVISIONING_RESULT);
						if (simResult != null && (ProvisioningResult.STATUS_COMMITTED.equals(simResult) || ProvisioningResult.STATUS_FAILED.equals(simResult)
								|| ProvisioningResult.STATUS_QUEUED.equals(simResult) || ProvisioningResult.STATUS_RETRY.equals(simResult))) {
							masterResult.setStatus(simResult);
						} else {
							masterResult.setStatus(ProvisioningResult.STATUS_COMMITTED);
						}
					} else {
						masterResult = masterConnector.provision(plan);
					}
					if (masterResult == null) {
						masterResult = new ProvisioningResult();
					}
					if (log.isDebugEnabled()) {
						log.debug(LogiPlexTools.stripControls(String.format("Result from master connector: %s", masterResult.toXml())));
					}

					// Re-get the lists of account and object requests.
					accountRequests = plan.getAccountRequests();
					objectRequests = plan.getObjectRequests();

					// Gather errors and warnings from account and object
					// requests
					// and add these to the original plan and provisioning
					// result
					// returned from the method.
					if (accountRequests != null && !accountRequests.isEmpty()) {
						for (AccountRequest accountRequest : plan.getAccountRequests()) {
							ProvisioningResult subResult = accountRequest.getResult();
							if (subResult != null) {
								List<Message> errors = subResult.getErrors();
								List<Message> warnings = subResult.getWarnings();
								if (errors != null) {
									for (Message message : errors) {
										masterResult.addError((Message) message.deepCopy((XMLReferenceResolver) context));
									}
								}
								if (warnings != null) {
									for (Message message : warnings) {
										masterResult.addWarning((Message) message.deepCopy((XMLReferenceResolver) context));
									}
								}
							}
						}
					}
					if (objectRequests != null && !objectRequests.isEmpty()) {
						for (ObjectRequest objectRequest : plan.getObjectRequests()) {
							ProvisioningResult subResult = objectRequest.getResult();
							if (subResult != null) {
								List<Message> errors = subResult.getErrors();
								List<Message> warnings = subResult.getWarnings();
								if (errors != null) {
									for (Message message : errors) {
										masterResult.addError((Message) message.deepCopy((XMLReferenceResolver) context));
									}
								}
								if (warnings != null) {
									for (Message message : warnings) {
										masterResult.addWarning((Message) message.deepCopy((XMLReferenceResolver) context));
									}
								}
							}
						}
					}

					// Add the generated account requests to the original plan
					if (accountRequests != null && !accountRequests.isEmpty()) {
						if (log.isTraceEnabled()) {
							log.trace(LogiPlexTools.stripControls(String.format("Original plan before applying account changes: %s", originalPlan.toXml())));
						}
						for (AccountRequest accountRequest : accountRequests) {
							String originalTarget = (String) accountRequest.getArgument(ARG_ORIGINAL_TARGET_APP);
							String currentTarget = accountRequest.getApplication();
							AccountRequest matchingAccountRequest = LogiPlexTools.getMatchingAccountRequest(originalPlan, accountRequest);
							ProvisioningResult accountRequestResult = accountRequest.getResult();
							if (log.isTraceEnabled()) {
								log.trace(LogiPlexTools.stripControls(String.format("Processing account request to apply to original plan:\n %s\nOriginal Target: %s\nCurrent Target: %s",
										accountRequest.toXml(), originalTarget, currentTarget)));
								log.trace(LogiPlexTools
										.stripControls(String.format("Matching account request from original plan: %s", (matchingAccountRequest != null) ? matchingAccountRequest.toXml() : "NULL")));
								log.trace(LogiPlexTools
										.stripControls(String.format("Account request result: %s / ResourceObject: %s", (accountRequestResult != null) ? accountRequestResult.toXml() : "NULL",
												(accountRequestResult != null && accountRequestResult.getObject() != null) ? accountRequestResult.getObject().toXml() : "NULL")));
							}
							if (accountRequestResult != null && matchingAccountRequest != null) {
								// Copy Provisioning Result.
								ProvisioningResult matchingAccountRequestResult = (ProvisioningResult) accountRequestResult.deepCopy(context);
								if (accountRequestResult.getObject() != null) {
									matchingAccountRequestResult.setObject((ResourceObject) accountRequestResult.getObject().deepCopy(context));
								}
								// Check native identity on the original request and try to fix if missing.
								matchingAccountRequest.setResult(matchingAccountRequestResult);
								if (Util.isNullOrEmpty(matchingAccountRequest.getNativeIdentity())) {
									if (log.isTraceEnabled()) {
										log.trace("Original account request does not have a native identity - trying to fix that");
									}
									String nativeIdentity = accountRequest.getNativeIdentity();
									if (Util.isNullOrEmpty(nativeIdentity) && (accountRequestResult != null && accountRequestResult.getObject() != null)) {
										ResourceObject ro = accountRequestResult.getObject();
										if (log.isTraceEnabled()) {
											log.trace(LogiPlexTools.stripControls(String.format(" - Trying to get the native identity from the ResourceObject: '%s'", nativeIdentity)));
										}
										nativeIdentity = ro.getIdentity();
									}
									if (Util.isNotNullOrEmpty(nativeIdentity)) {
										if (log.isTraceEnabled()) {
											log.trace(LogiPlexTools.stripControls(String.format(" - Found new native identity: '%s'", nativeIdentity)));
										}
										matchingAccountRequest.setNativeIdentity(nativeIdentity);
									}
								}
							}
							if (!LogiPlexTools.getMainApplication(context, getApplication()).getName().equals(originalTarget)) {
								// In case of Create requests for sub-applications adding created request to the original
								// plan causes duplicate entitlements being created. Filtering it out.

								// It turns out that duplicated entitlements are also created when provisioning is launched by RoleChangePropagatorTask
								// removing condition that checks for Operation=Create
								if (matchingAccountRequest != null) {
									if (LogiPlexTools.getMainApplication(context, getApplication()).getName().equals(currentTarget)) {
										AccountRequest strippedAccountRequest = stripEntitlementChanges(accountRequest, matchingAccountRequest);
										if (strippedAccountRequest != null) {
											if (log.isTraceEnabled()) {
												log.trace(LogiPlexTools.stripControls(String.format("Stripped account request: %s", strippedAccountRequest.toXml())));
											}
											originalPlan.add(strippedAccountRequest);
										}
									}
								} else {
									originalPlan.add(accountRequest);
								}
							} else {
								if (LogiPlexTools.getMainApplication(context, getApplication()).getName().equals(currentTarget)) {
									Identity identity = getIdentityFromPlan(originalPlan);
									if (identity == null) {
										throw new GeneralException("Plan does not have an identity");
									}
									switch (accountRequest.getOperation()) {
									case Delete:
									case Enable:
									case Disable:
									case Lock:
									case Unlock:
										// For these operations, apply the changes
										// to the sub-applications as well.
										List<String> san = getSubApplicationNames(getApplication());
										if (san != null) {
											if (log.isTraceEnabled()) {
												log.trace(LogiPlexTools.stripControls(String.format("Sub-application names: %s", san)));
											}
											for (String name : san) {
												Application subApp = context.getObjectByName(Application.class, name);
												IdentityService service = new IdentityService(context);
												Link link = service.getLink(identity, subApp, accountRequest.getInstance(), accountRequest.getNativeIdentity());
												if (link != null) {
													AccountRequest subAccountRequest = new AccountRequest();
													ProvisioningResult subAccountResult = new ProvisioningResult();
													subAccountRequest.fromMap(accountRequest.toMap());
													subAccountRequest.setApplication(name);
													ProvisioningResult accountResult = accountRequest.getResult();
													if (accountResult != null) {
														subAccountResult.setStatus(accountResult.getStatus());
														List<Message> errors = accountResult.getErrors();
														List<Message> warnings = accountResult.getWarnings();
														if (errors != null && !errors.isEmpty()) {
															for (Message error: errors) {
																subAccountResult.addError((Message) error.deepCopy(context));
															}
														}
														if (warnings != null && !warnings.isEmpty()) {
															for (Message warning: warnings) {
																subAccountResult.addWarning((Message) warning.deepCopy(context));
															}
														}
														subAccountResult.setRetryInterval(accountResult.getRetryInterval());
														subAccountResult.setRequestID(accountResult.getRequestID());
													} else {
														subAccountResult = new ProvisioningResult();
														subAccountResult.setStatus(masterResult.getStatus());
													}
													subAccountRequest.setResult(subAccountResult);
													if (log.isTraceEnabled()) {
														log.trace(LogiPlexTools.stripControls(String.format("Adding constructed sub-account request: %s", subAccountRequest.toXml())));
													}
													originalPlan.add(subAccountRequest);
												}
											}
										}
										break;
									default:
										break;
									}
								}
							}
						}
						if (log.isTraceEnabled()) {
							log.trace(LogiPlexTools.stripControls(String.format("Original plan after applying account changes: %s", originalPlan.toXml())));
						}
					}

					// Add the generated object requests to the original plan
					if (objectRequests != null && !objectRequests.isEmpty()) {
						if (log.isTraceEnabled()) {
							log.trace(LogiPlexTools.stripControls(String.format("Original plan before applying group changes: %s", originalPlan.toXml())));
						}
						for (ObjectRequest objectRequest : objectRequests) {
							String originalTarget = (String) objectRequest.getArgument(ARG_ORIGINAL_TARGET_APP);
							if (!LogiPlexTools.getMainApplication(context, getApplication()).getName().equals(originalTarget)) {
								if (log.isTraceEnabled()) {
									log.trace(LogiPlexTools.stripControls(String.format("Adding sub-application object request: %s", objectRequest.toXml())));
								}
								originalPlan.add(objectRequest);
							}
						}
						if (log.isTraceEnabled()) {
							log.trace(LogiPlexTools.stripControls(String.format("Original plan after applying group changes: %s", originalPlan.toXml())));
						}
					}

					// TODO: Update original plan's account requests with errors/warnings from corresponding requests.

					// Re-aggregate accounts and groups to reflect the changes to the plan and on the cube.
					if (simulate) {
						if (log.isInfoEnabled()) {
							log.info("Simulated Provisioniong - Skipping re-aggregation");
						}
					} else {
						postProvisionUpdatePlanUsingAggregation(originalPlan, masterResult);
					}
					
					postProvisioningFilterPlan(originalPlan);

					// Set the result(s) on the original plan and return the
					// composed result.
					originalPlan.setResult(masterResult);
					if (log.isTraceEnabled()) {
						log.trace(originalPlan.toXml());
					}
					return masterResult;
				} else {
					log.warn("No plan or empty plan - ignoring.");
					return new ProvisioningResult();
				}
			} catch (GeneralException e) {
				log.error(e);
				throw new ConnectorException(e);
			}
		}

		ProvisioningResult planResult = null;
		return planResult;
	}

	/**
	 * Perform split on the ResourceObject received from the underlying connector.
	 *
	 * @param authenticate
	 * @return
	 * @throws AuthenticationFailedException
	 * @throws ObjectNotFoundException
	 */
	private ResourceObject processAuthenticationObject(ResourceObject authenticate) throws AuthenticationFailedException, ObjectNotFoundException {
		if (authenticate != null) {
			try {
				String applicationName = getApplication().getName();
				String targetApplicationName = applicationName;
				Application targetApplication = getTargetApplication();
				if (targetApplication != null) {
					targetApplicationName = targetApplication.getName();
				}
				Map<String, ResourceObject> objects = util.splitResourceObject(authenticate);
				authenticate = objects.get(targetApplicationName);
				if (log.isTraceEnabled()) {
					log.trace(LogiPlexTools.stripControls(String.format("Application: %s / Target: %s %nSplit Map: %s", applicationName, targetApplicationName, objects)));
					log.trace(LogiPlexTools.stripControls(String.format("Authentication result ResourceObject: %s", authenticate)));
				}
				if (authenticate == null) {
					throw new ObjectNotFoundException(String.format("User not found on application %s", targetApplicationName));
				}
			} catch (GeneralException e) {
				String errorMessage = String.format("Error running split rule after authentication: %s", e.getMessage());
				log.error(errorMessage);
				throw new AuthenticationFailedException(errorMessage, e);
			}
		}
		return authenticate;
	}

	/**
	 * Pass authentication request on to the master connector.
	 *
	 * @param accountId
	 * @param options
	 * @return
	 * @throws ConnectorException
	 * @throws ObjectNotFoundException
	 * @throws AuthenticationFailedException
	 * @throws ExpiredPasswordException
	 */
	@Override
	public ResourceObject authenticate(String accountId, Map<String, Object> options) throws ConnectorException, ObjectNotFoundException, AuthenticationFailedException, ExpiredPasswordException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: authenticate(%s, %s)", accountId, options)));
		}
		ResourceObject authenticate = processAuthenticationObject(this.masterConnector.authenticate(accountId, options));
		setAuthenticateDetails(authenticate);
		return authenticate;
	}

	/**
	 * Pass authentication request on to the master connector.
	 *
	 * @param username
	 * @param password
	 * @return
	 * @throws ConnectorException
	 * @throws ObjectNotFoundException
	 * @throws AuthenticationFailedException
	 * @throws ExpiredPasswordException
	 */
	@Override
	public ResourceObject authenticate(String username, String password) throws ConnectorException, ObjectNotFoundException, AuthenticationFailedException, ExpiredPasswordException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: authenticate(%s, %s)", username, "********")));
		}
		ResourceObject authenticate = processAuthenticationObject(this.masterConnector.authenticate(username, password));
		setAuthenticateDetails(authenticate);
		return authenticate;
	}

	/**
	 * Set flag on resource object to indicate that ResourceObject was retrieved during PTA
	 * 
	 * @param authenticate
	 */
	private void setAuthenticateDetails(ResourceObject authenticate) {
		if (authenticate != null) {
			authenticate.setAttribute(LOGIPLEX_AUTHENTICATE_OBJECT, Boolean.TRUE);
		}
	}

	/**
	 * Pass requests to verify provisioning results on to the master connector.
	 *
	 * @param id
	 * @return
	 * @throws ConnectorException
	 * @throws GeneralException
	 */
	@Override
	public ProvisioningResult checkStatus(String id) throws ConnectorException, GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: checkStatus(%s)", id)));
		}
		return this.masterConnector.checkStatus(id);
	}

	@Override
	public List<AttributeDefinition> getDefaultAttributes() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getDefaultAttributes()");
		}
		List<AttributeDefinition> defaultAttributes = new ArrayList<AttributeDefinition>();
		defaultAttributes.add(new AttributeDefinition("masterApplication", "string", "Master application name or id", true, ""));
		defaultAttributes.add(new AttributeDefinition("logiPlexPrefix", "string", "Prefix for generated applications", false, ""));
		return defaultAttributes;
	}

	/**
	 * Test the connector. This request is passed on to the master connector.
	 *
	 * @throws ConnectorException
	 */
	public void testConfiguration() throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: testConfiguration()");
		}
		if (masterConnector == null) {
			throw new ConnectorException("No master connector set");
		}
		this.masterConnector.testConfiguration();
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<Schema> getDefaultSchemas() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getDefaultSchemas()");
		}
		return this.masterConnector.getDefaultSchemas();
	}

	/**
	 * Use the master connector to discover the schema. If that doesn't work, it
	 * will try to fetch the defined schema from the master application
	 * definition.
	 *
	 * @param objectType
	 * @param options
	 * @return
	 * @throws ConnectorException
	 */
	@Override
	public Schema discoverSchema(final String objectType, final Map<String, Object> options) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: discoverSchema(%s, %s)", objectType, options)));
		}
		if (masterApplication == null) {
			throw new ConnectorException("No master application set");
		}
		if (masterConnector == null) {
			throw new ConnectorException("No master connector set");
		}
		try {
			Schema schema = this.masterConnector.discoverSchema(objectType, options);
			schema = (Schema) schema.deepCopy((Resolver) context);
			schema.setId(null);
			return schema;
		} catch (java.lang.UnsupportedOperationException e) {
			log.warn(LogiPlexTools.stripControls(String.format("Master Connector threw exception while trying to discover schema: %s", e.getMessage())));
			if (log.isDebugEnabled()) {
				log.debug(LogiPlexTools.stripControls(String.format("Getting Schema for object type %s from master application", objectType)));
			}
			Schema schema = masterApplication.getSchema(objectType);
			if (schema != null) {
				try {
					schema = (Schema) schema.deepCopy((Resolver) context);
					schema.setId(null);
					return schema;
				} catch (GeneralException e1) {
					log.error(e);
					throw new ConnectorException(e);
				}
			}
			throw new ConnectorException(LogiPlexTools.stripControls(String.format("Master application does not have a schema for object type %s", objectType)));
		} catch (GeneralException e) {
			log.error(e);
			throw new ConnectorException(e);
		}
	}

	@Override
	public Map<String, Object> discoverApplicationAttributes(Map<String, Object> options) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(LogiPlexTools.stripControls(String.format("Enter: discoverApplicationAttributes(%)", options)));
		}
		return this.masterConnector.discoverApplicationAttributes(options);
	}

	/**
	 * Runtime exception to be thrown in case of an issue while iterating.
	 *
	 * @author menno.pieters
	 */
	public class LogiPlexIteratorException extends RuntimeException {

		public LogiPlexIteratorException(Throwable e) {
			super(e);
		}

		/**
		 *
		 */
		private static final long serialVersionUID = -5924669785877532031L;
	}

	/**
	 * Special iterator class that allows for copying/splitting the
	 * ResourceObjects before returning them.
	 *
	 * @param <E>
	 * @author menno.pieters@sailpoint.com
	 */
	public class LogiPlexIterator<E> implements Iterator<ResourceObject>, CloseableIterator<ResourceObject> {

		public final static int MAX_FILL_RETRY = 10;
		private Map<String, Object> options = null;
		private final Logger log = Logger.getLogger(LogiPlexIterator.class);
		private CloseableIterator<ResourceObject> masterIterator = null;
		private Queue<ResourceObject> queue = new ConcurrentLinkedQueue<ResourceObject>();
		private LogiPlexUtil util;
		private Connector masterConnector = null;
		private int objectCount = 0;
		private String objectType = null;

		/**
		 * Constructor
		 *
		 * @param masterConnector
		 * @param masterIterator
		 * @param util
		 * @param options
		 * @throws GeneralException
		 */
		public LogiPlexIterator(String objectType, Connector masterConnector, CloseableIterator<ResourceObject> masterIterator, LogiPlexUtil util, Map<String, Object> options)
				throws GeneralException {
			super();
			if (log.isDebugEnabled()) {
				log.debug(LogiPlexTools.stripControls(String.format("Constructor: LogiPlexIterator(%s, %s)", masterIterator, util)));
			}
			if (masterIterator == null) {
				throw new GeneralException("Master iterator must not be null");
			}
			this.masterConnector = masterConnector;
			this.masterIterator = masterIterator;
			this.objectType = objectType;
			this.util = util;
			this.options = options;
		}

		/**
		 * Determine whether the aggregation is performed in delta mode (true)
		 * or not (false).
		 *
		 * @return true if a delta aggregation is being performed.
		 */
		private boolean isDelta() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: isDelta()");
			}
			boolean delta = false;
			if (options != null) {
				if (options.containsKey("deltaAggregation")) {
					delta = Util.otob(options.get("deltaAggregation"));
				}
			}
			if (log.isDebugEnabled()) {
				log.debug(String.format("Exit: isDelta(): %b", delta));
			}
			return delta;
		}

		/**
		 * Close the iterator and underlying master iterator.
		 */
		public void close() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: close()");
			}
			if (log.isTraceEnabled()) {
				log.trace(String.format("Objects processed: %d", objectCount));
			}
			masterIterator.close();
		}

		/**
		 * Read the next item from the master iterator and run the split rule,
		 * if available. Add the results to the internal queue.
		 *
		 * In delta iteration mode, it may have to try again a couple of times.
		 * At least the Active Directory DirSync iterator may sometimes report
		 * true for the hasNext() method, but still return null when next() is
		 * called. In that case, a new call must be made to hasNext() and
		 * next(), up until a maximum number of retries.
		 *
		 * Possibly other connectors show similar behavior.
		 *
		 * @throws GeneralException
		 */
		private void fillQueue() throws GeneralException {
			if (log.isDebugEnabled()) {
				log.error("Enter: fillQueue()");
			}
			boolean hasNext = masterIterator.hasNext();
			if (!hasNext && isDelta()) {
				int tryCount = 1;
				while (!hasNext && tryCount <= MAX_FILL_RETRY) {
					if (log.isTraceEnabled()) {
						log.trace(String.format("No result in delta mode; retrying %d", tryCount));
					}
					hasNext = masterIterator.hasNext();
					tryCount++;
				}
			}
			if (log.isTraceEnabled()) {
				log.trace(String.format("fillQueue: hasNext: %b", hasNext));
			}
			if (hasNext) {
				ResourceObject object = masterIterator.next();
				// reference to MAX_FILL_RETRY = 10 property was removed as it may be easily exceeded with large number of changes handled by delta aggregation
				// There is similar logic in OOTB ConnectorProxy.peek() class, where we iterate until object != null or we reach end of iterator (without
				// specifying max retries)
				while (hasNext && object == null) {
					/*
					 * The master iterator indicated that more objects are
					 * available, but no object was returned. We need to try
					 * again.
					 */
					if (log.isTraceEnabled()) {
						log.trace("fillQueue: null object returned");
					}
					hasNext = masterIterator.hasNext();
					if (hasNext) {
						object = masterIterator.next();
					}
				}
				if (object != null) {
					objectCount++;
					/*
					 * We go an object. Now we need to run this object through
					 * the split rule.
					 */
					if (log.isTraceEnabled()) {
						log.trace("fillQueue: " + object.getIdentity());
					}
					// Fill object type if not set by master iterator
					if (object.getObjectType() == null) {
						object.setObjectType(this.objectType);
					}
					// Check for incomplete or incremental objects (typically during delta)
					if ((object.isIncomplete() || object.isIncremental()) && masterConnector != null) {
						/*
						 * During delta aggregation, we may get an incomplete or incremental
						 * object, containing only the attributes that have been
						 * updated.
						 */
						if (log.isDebugEnabled()) {
							log.debug("Incomplete - getting full object: " + object.toXml());
						}
						try {
							ResourceObject tempObject = masterConnector.getObject(object.getObjectType(), object.getIdentity(), new HashMap<String, Object>());
							if (tempObject != null) {
								object = tempObject;
							}
						} catch (ConnectorException e) {
							log.error(e);
						}
						if (log.isTraceEnabled()) {
							log.trace("fillQueue: full object:" + object.toXml());
						}
					}
					Map<String, ResourceObject> map = util.splitResourceObject(object);
					List<ResourceObject> list = util.mapToList(map);
					if (list != null && !list.isEmpty()) {
						for (ResourceObject o: list) {
							if (o != null) {
								queue.add(o);
							}
						}
					}
				} else {
					log.warn("fillQueue: null object returned");
				}
			} else {
				log.warn("fillQueue: No more results.");
			}
		}

		/**
		 * Check whether more objects are available for aggregation. First check
		 * whether the internal queue has more objects. If so return true. If
		 * not, try to fill the queue with objects from the master iterator.
		 * Then return true if the queue has new objects.
		 *
		 * @return true if there are more objects available
		 */
		public boolean hasNext() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: hasNext()");
			}
			if (!queue.isEmpty()) {
				log.trace("Internal queue still has items");
				return true;
			}
			if (log.isTraceEnabled()) {
				log.trace("Try master iterator");
			}
			try {
				fillQueue();
			} catch (GeneralException e) {
				log.error(e);
				throw new LogiPlexIteratorException(e);
			}
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("hasNext(): %b", !queue.isEmpty())));
			}
			return !queue.isEmpty();
		}

		/**
		 * Return the next object from the internal queue. If there are no more
		 * elements, first try to fill the queue with objects from the master
		 * iterator, processed by the split rule.
		 *
		 * @return a resource object for the main or a sub-application
		 */
		public ResourceObject next() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: next()");
			}
			if (queue.isEmpty()) {
				log.debug("Queue is empty. Try to refill queue");
				try {
					fillQueue();
				} catch (GeneralException e) {
					log.error(e);
					throw new LogiPlexIteratorException(e);
				}
			}
			ResourceObject object = queue.poll();
			try {
				if (object != null) {
					if (log.isTraceEnabled()) {
						log.trace(object.toXml());
					}
				} else {
					log.warn("null object");
				}
			} catch (GeneralException e) {
				log.error(e);
			}
			return object;
		}
	}

	/**
	 * Utility class to support the LogiPlex connector and iterator.
	 *
	 * @author menno.pieters@sailpoint.com
	 */
	public class LogiPlexUtil {

		private final Logger log = Logger.getLogger(LogiPlexUtil.class);
		private Attributes<String, Object> mainSettings = null;
		private String applicationName = null;
		private SailPointContext context;
		private Map<String, Object> state = new HashMap<String, Object>();
		private Rule splitRule = null;

		/**
		 * Constructor.
		 *
		 * @param context
		 *            The SailPointContext.
		 * @param applicationName
		 *            The name of the LogiPlex Application
		 * @param masterSettings
		 *            The masterSettings for the application.
		 * @throws GeneralException
		 */
		public LogiPlexUtil(SailPointContext context, String applicationName, Attributes<String, Object> mainSettings) throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Constructor: LogiPlexUtil(Context, %s, %s)", applicationName, mainSettings)));
			}
			if (mainSettings == null) {
				throw new GeneralException("No settings supplied");
			}
			if (applicationName == null) {
				log.warn("No application name supplied");
			}
			this.context = context;
			this.mainSettings = mainSettings;
			this.applicationName = applicationName;
		}

		/**
		 * Get the split rule from the LogiPlex application definition.
		 *
		 * @return The rule configured to split the retrieved ResourceObject.
		 *         Null if none is configured.
		 * @throws GeneralException
		 */
		private Rule getSplitRule() throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace("Enter: getSplitRule");
			}
			if (splitRule == null) {
				String ruleName = mainSettings.getString(LOGIPLEX_AGGREGATION_RULE);
				if (ruleName != null) {
					splitRule = context.getObjectByName(Rule.class, ruleName);
					if (splitRule == null) {
						log.error(LogiPlexTools.stripControls(String.format("Rule %s not found.", ruleName)));
					}
				}
			}
			return splitRule;
		}

		/**
		 * Prefix a sub-application name with the prefix.
		 *
		 * @param name
		 * @param prefix
		 * @return the prefixed name
		 */
		public String applyApplicationPrefix(final String name, final String prefix) {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: applyApplicationPrefix(%s, %s)", name, prefix)));
			}
			if (Util.isNullOrEmpty(name)) {
				return null;
			}
			if (Util.isNullOrEmpty(prefix)) {
				return name;
			}
			String resourceName = "";
			String localPrefix = prefix;
			if (!prefix.endsWith("-")) {
				localPrefix += "-";
			}
			if (!name.startsWith(localPrefix) && !name.equals(applicationName)) {
				resourceName += localPrefix;
			}
			resourceName += name;
			return resourceName;
		}

		/**
		 * Update the keys with the configured prefix and return a new map.
		 *
		 * @param objects
		 * @param prefix
		 * @return
		 */
		public Map<String, ResourceObject> applyApplicationPrefix(final Map<String, ResourceObject> objects, final String prefix) {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: applyApplicationPrefix(%s, %s)", objects, prefix)));
			}
			if (objects == null) {
				return null;
			}
			if (Util.isNullOrEmpty(prefix)) {
				return objects;
			}
			Map<String, ResourceObject> newObjects = new HashMap<String, ResourceObject>();
			for (String key : objects.keySet()) {
				ResourceObject object = objects.get(key);
				String newKey = applyApplicationPrefix(key, prefix);
				newObjects.put(newKey, object);
			}
			return newObjects;
		}

		/**
		 * Convert a map of application names and resource objects to a List.
		 * Prefix the application names, if configured to do so and set the
		 * IIQSourceApplication attribute on the ResourceObject, if not yet set.
		 *
		 * @param map
		 *            The Map to be converted to a List object.
		 * @return A list of ResourceObjects.
		 */
		public List<ResourceObject> mapToList(Map<String, ResourceObject> map) {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: mapToList(%s)", map)));
			}
			List<ResourceObject> results = new ArrayList<ResourceObject>();
			if (map != null) {
				for (String key : map.keySet()) {
					ResourceObject object = map.get(key);
					if (!key.equals(applicationName)) {
						String resourceName = object.getString("IIQSourceApplication");
						if (Util.isNullOrEmpty(resourceName)) {
							log.info("Split rule has not set IIQSourceApplication - using key and prefix to generate");
							resourceName = key;
							log.info(LogiPlexTools.stripControls(String.format("Setting IIQSourceApplication: %s", resourceName)));
							object.put("IIQSourceApplication", resourceName);
						}
					} else {
						// Skip if application equals main application.
					}
					results.add(object);
				}
			}
			return results;
		}

		/**
		 * Update a map of lists.
		 *
		 * @param map
		 *            The map to be updated. If null, a new map will be created.
		 * @param key
		 *            The key for the List to be updated.
		 * @param value
		 *            The value to be added to the List in the map.
		 * @return An updated map with List objects for each key.
		 */
		public Map<String, List<Object>> updateListMap(Map<String, List<Object>> map, String key, Object value) {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: updateListMap(%s, %s, %s)", map, key, value)));
			}
			if (map == null) {
				map = new HashMap<String, List<Object>>();
			}
			if (key != null) {
				List<Object> list = map.get(key);
				if (list == null) {
					list = new ArrayList<Object>();
				}
				if (value != null && !list.contains(value)) {
					list.add(value);
				}
				map.put(key, list);
			}
			return map;
		}

		/**
		 * Get a Link representing the account matching the input parameters.
		 *
		 * @param applicationName
		 * @param instance
		 * @param nativeIdentity
		 * @return a Link object if found.
		 */
		private Link getAccountLink(String applicationName, String instance, String nativeIdentity) {
			if (Util.isNotNullOrEmpty(applicationName) && Util.isNotNullOrEmpty(nativeIdentity)) {
				List<Filter> filters = new ArrayList<Filter>();
				filters.add(Filter.eq("application.name", applicationName));
				if (Util.isNotNullOrEmpty(instance)) {
					filters.add(Filter.eq("instance", instance));
				}
				filters.add(Filter.eq("nativeIdentity", nativeIdentity));
				try {
					return this.context.getUniqueObject(Link.class, Filter.and(filters));
				} catch (GeneralException e) {
					log.warn(String.format("Unable to find unique account on application %s with name %s", applicationName, nativeIdentity), e);
					if (log.isDebugEnabled()) {
						log.error(e.getMessage(), e);
					}
				}
			}
			return null;
		}

		/**
		 * Get a Link representing the account matching the application name and resource object.
		 *
		 * @param applicationName
		 * @param object
		 * @return a Link object if found.
		 */
		private Link getAccountLink(String applicationName, ResourceObject object) {
			return getAccountLink(applicationName, object.getInstance(), object.getIdentity());
		}

		private ManagedAttribute getManagedAttribute(String applicationName, String type, String instance, String nativeIdentity) {
			if (Util.isNotNullOrEmpty(applicationName) && Util.isNotNullOrEmpty(type) && Util.isNotNullOrEmpty(nativeIdentity)) {
				List<Filter> filters = new ArrayList<Filter>();
				filters.add(Filter.eq("application.name", applicationName));
				if (Util.isNotNullOrEmpty(instance)) {
					filters.add(Filter.eq("instance", instance));
				}
				filters.add(Filter.eq("type", type));
				filters.add(Filter.eq("value", nativeIdentity));
				try {
					return (ManagedAttribute) this.context.getUniqueObject(ManagedAttribute.class, Filter.and(filters));
				} catch (GeneralException e) {
					log.warn(String.format("Unable to find unique managed attribute object on application %s with type %s and name %s", applicationName, type, nativeIdentity), e);
					if (log.isDebugEnabled()) {
						log.error(e.getMessage(), e);
					}
				}
			}
			return null;
		}

		private ManagedAttribute getManagedAttribute(String applicationName, ResourceObject object) {
			if (object != null) {
				return getManagedAttribute(applicationName, object.getObjectType(), object.getInstance(), object.getIdentity());
			}
			return null;
		}

		/**
		 * Split the ResourceObject into separate items per application.
		 *
		 * @param object
		 *            The ResourceObject to be inspected and split.
		 * @return A Map of application names and ResourceObjects.
		 * @throws GeneralException
		 */
		@SuppressWarnings("unchecked")
		public Map<String, ResourceObject> splitResourceObject(ResourceObject object) throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: splitResourceObject(%s)", object)));
			}
			Map<String, ResourceObject> results = new HashMap<String, ResourceObject>();

			if (object.isDelete()) {
				if (log.isDebugEnabled()) {
					log.debug("Delete event: using default logic for deletions");
				}
				if ("account".equals(object.getObjectType())) {
					if (log.isDebugEnabled()) {
						log.debug("Account deletion: look up sub-accounts and add a delete event for these objects, too.");
					}
					results.put(applicationName, object);
					Link mainLink = getAccountLink(this.applicationName, object);
					if (mainLink != null) {
						List<String> subApplicationNames = LogiPlexTools.getSubApplicationNames(context, context.getObjectByName(Application.class, applicationName));
						if (subApplicationNames != null && !subApplicationNames.isEmpty()) {
							for (String subApplicationName : subApplicationNames) {
								Link subLink = getAccountLink(subApplicationName, object);
								if (subLink != null) {
									ResourceObject subObject = (ResourceObject) object.deepCopy(context);
									results.put(subApplicationName, subObject);
								}
							}
						}
					}
				} else {
					if (log.isDebugEnabled()) {
						log.debug("Group deletion: look up managed attributes for main and sub-applications and add a delete event for these objects, too.");
					}
					List<String> applicationNames = new ArrayList<String>();
					applicationNames.add(applicationName);
					List<String> subApplicationNames = LogiPlexTools.getSubApplicationNames(context, context.getObjectByName(Application.class, applicationName));
					if (subApplicationNames != null && !subApplicationNames.isEmpty()) {
						applicationNames.addAll(subApplicationNames);
					}
					for (String name : applicationNames) {
						ManagedAttribute ma = getManagedAttribute(applicationName, object);
						if (ma != null) {
							ResourceObject subObject = (ResourceObject) object.deepCopy(context);
							results.put(name, subObject);
						}
					}
				}
			} else {
				Rule rule = getSplitRule();
				if (rule != null) {
					Map<String, Object> args = new HashMap<String, Object>();
					args.put("context", context);
					args.put("log", log);
					args.put("object", object);
					args.put("state", state);
					args.put("applicationName", applicationName);
					args.put("application", context.getObjectByName(Application.class, applicationName));
					args.put("map", new HashMap<String, Object>());
					args.put("util", this);
					Object result = context.runRule(getSplitRule(), args);
					if (result instanceof Map) {
						String prefix = mainSettings.getString(LOGIPLEX_ATTR_PREFIX);
						results.putAll((applyApplicationPrefix((Map<String, ResourceObject>) result, prefix)));
					} else if (result != null) {
						throw new GeneralException("Unsupported return type: expected a Map<String, ResourceObject>.");
					}
				} else {
					log.warn("No split rule defined, adding object to default application name.");
					results.put(this.applicationName, object);
				}
			}
			return results;
		}
	}

	/**
	 * Static class with additional helper methods.
	 *
	 * @author menno.pieters
	 */
	public static class LogiPlexTools {

		private final static Logger log = Logger.getLogger(LogiPlexTools.class.getName());

		/**
		 * Get the main application. If the application has a proxy, return the
		 * proxy, otherwise the application is considered the main application.
		 *
		 * @param context
		 *            The current SailPointContext.
		 * @param application
		 *            The application for which the main application must be
		 *            found.
		 * @return The main LogiPlex application.
		 * @throws GeneralException
		 */
		public static Application getMainApplication(SailPointContext context, Application application) throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: getMainApplication(%s)", application)));
			}
			if (application == null) {
				return null;
			}
			Application proxy = application.getProxy();
			if (proxy == null) {
				String cgwProxyName = application.getStringAttributeValue(LogiPlexConnector.LOGIPLEX_ATTR_CGW_PROXY_APPLICATION);
				if (Util.isNotNullOrEmpty(cgwProxyName)) {
					Application cgwProxy = context.getObjectByName(Application.class, cgwProxyName);
					if (cgwProxy != null) {
						log.debug(LogiPlexConnector.LOGIPLEX_ATTR_CGW_PROXY_APPLICATION + " set - found main application");
						return cgwProxy;
					}
				}
				log.debug("No proxy, application is main application");
				return application;
			} else if (proxy.getType().equals(application.getType())) {
				log.debug(LogiPlexTools.stripControls(String.format("Found proxy application by type: %s", proxy)));
				return proxy;
			} else if (proxy.getConnector().equals(LogiPlexConnector.class.getName())) {
				log.debug(LogiPlexTools.stripControls(String.format("Found proxy application by connector class: %s", proxy)));
				return proxy;
			} else {
				log.debug("Proxy is not the same type, returning application");
				return application;
			}
		}

		/**
		 * Get a list of all application names that have the main application as
		 * proxy.
		 *
		 * @param context
		 *            The current SailPointContext.
		 * @param application
		 *            The main application
		 * @return A list of application names.
		 * @throws GeneralException
		 */
		public static List<String> getSubApplicationNames(SailPointContext context, Application application) throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: getSubApplicationNames(%s)", application)));
			}
			Set<String> applicationNames = new HashSet<String>();
			if (context != null && application != null) {
				application = getMainApplication(context, application);

				Filter filter = Filter.eq("proxy.name", application.getName());
				QueryOptions qo = new QueryOptions();
				qo.addFilter(filter);
				qo.setDistinct(true);
				try {
					Iterator<Object[]> iterator = context.search(Application.class, qo, "name");
					while (iterator != null && iterator.hasNext()) {
						Object[] data = iterator.next();
						String name = (String) data[0];
						applicationNames.add(name);
					}
				} catch (GeneralException e) {
					log.error("Unable to retrieve sub-applications", e);
					throw e;
				}
			}
			return new ArrayList<String>(applicationNames);
		}

		/**
		 * Check whether the account request application is the main
		 * application.
		 *
		 * @param context
		 *            The current SailPointContext.
		 * @param application
		 *            The application to be tested.
		 * @param req
		 *            The account request to be tested
		 * @return True if the request is for the main application, otherwise
		 *         false.
		 * @throws GeneralException
		 */
		public static boolean isMainApplicationRequest(SailPointContext context, Application application, AbstractRequest req) throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: isMainApplicationRequest(%s, %s)", application, req)));
			}
			Application mainApplication = getMainApplication(context, application);
			if (req != null && mainApplication != null) {
				return req.getApplication().equals(mainApplication.getName());
			}
			return false;
		}

		/**
		 * Get the Link object corresponding to the account request.
		 *
		 * @param context
		 *            The current SailPointContext.
		 * @param identity
		 * @param req
		 * @return
		 * @throws GeneralException
		 */
		public static Link getLink(SailPointContext context, Identity identity, AccountRequest req) throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: getLink(%s, %s, %s)", context, identity, req)));
			}
			if (req != null) {
				String nativeIdentity = req.getNativeIdentity();
				if (nativeIdentity != null) {
					IdentityService service = new IdentityService(context);
					return service.getLink(identity, req.getApplication(context), req.getInstance(), nativeIdentity);
				}
			}
			return null;
		}

		/**
		 * This method iterates over all links and returns matching links. The
		 * method is needed to support the Cloud Gateway. On the Cloud Gateway,
		 * calling the IdentityService to get Link objects for a specific
		 * application may result in a NullPointerException as not all
		 * applications in identity links will be synchronized to the Cloud
		 * Gateway. Iterating over the list of Links objects and comparing by
		 * application name does work, though.
		 *
		 * @param identity
		 *            The identity to get links from.
		 * @param application
		 *            The application to match. Return all links if the application is null.
		 * @param instance
		 *            The instance to match. If null, it will be ignored.
		 * @return All links that match the application and instance (if not
		 *         null). If the application is null all links will be returned.
		 */
		public static List<Link> getLinks(Identity identity, Application application, String instance) {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: getLinks(%s, %s, %s)", identity, application, instance)));
			}
			if (identity != null) {
				List<Link> allLinks = identity.getLinks();
				if (allLinks != null) {
					List<Link> links = new ArrayList<Link>();
					for (Link link : allLinks) {
						if (application != null) {
							if (application.getName().equals(link.getApplicationName()) && (instance == null || instance.equals(link.getInstance()))) {
								links.add(link);
							}
						} else {
							links.add(link);
						}
					}
					return links;
				}
			}
			return null;
		}

		/**
		 * Get the Link object for the main application, corresponding to the
		 * account request.
		 *
		 * @param context
		 * @param identity
		 * @param application
		 * @param req
		 * @return
		 * @throws GeneralException
		 */
		public static Link getMainLink(SailPointContext context, Identity identity, Application application, AccountRequest req) throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: getMainLink(%s, %s, %s, %s)", context, identity, application, req)));
			}
			return getMainLink(context, identity, application, req, false, null);
		}

		/**
		 * Get the Link object for the main application, corresponding to the
		 * account request.
		 *
		 * @param context
		 * @param identity
		 * @param application
		 * @param req
		 * @return
		 * @throws GeneralException
		 */
		public static Link getMainLink(SailPointContext context, Identity identity, Application application, AccountRequest req, boolean useGetObject, Connector masterConnector)
				throws GeneralException {
			if (log.isTraceEnabled()) {
				log.trace(LogiPlexTools.stripControls(String.format("Enter: getMainLink(%s, %s, %s, %s, %b, %s)", context, identity, application, req, useGetObject, masterConnector)));
			}
			if (req != null) {
				IdentityService service = new IdentityService(context);
				String nativeIdentity = req.getNativeIdentity();
				Link link = null;
				Application mainApplication = getMainApplication(context, application);
				if (mainApplication != null) {
					boolean linkFromMaster = Util.otob(mainApplication.getAttributeValue(LOGIPLEX_ATTR_LINK_FROM_MASTER));
					if (log.isTraceEnabled()) {
						log.trace(LogiPlexTools.stripControls(String.format("linkFromMaster: %b for main application %s", linkFromMaster, mainApplication.toString())));
					}
					if (linkFromMaster) {
						String master = (String) mainApplication.getAttributeValue(LOGIPLEX_ATTR_MASTER_APPLICATION);
						Application masterApplication = context.getObject(Application.class, master);
						if (masterApplication != null) {
							mainApplication = masterApplication;
							if (log.isTraceEnabled()) {
								log.trace(LogiPlexTools.stripControls(String.format("Master Application as Main: %s", master)));
							}
						} else {
							throw new GeneralException(String.format("Unable to get master application for %s", mainApplication.getName()));
						}
					}
					// If the request has a selected account, use this to get
					// the main account
					if (Util.isNotNullOrEmpty(nativeIdentity)) {
						link = service.getLink(identity, mainApplication, req.getInstance(), nativeIdentity);
					}

					// If the option LogiPlexConnector.LOGIPLEX_ATTR_PROVISION_GET_OBJECT is enabled and no link
					// is found on the database, yet, check in the target application for existence.
					if (link == null && masterConnector != null && useGetObject) {
						if (log.isDebugEnabled()) {
							log.debug("Trying to read account from target system");
						}
						try {
							ResourceObject object = masterConnector.getObject(Schema.TYPE_ACCOUNT, req.getNativeIdentity(), new HashMap<String, Object>());
							if (object != null) {
								if (log.isTraceEnabled()) {
									log.trace(LogiPlexTools.stripControls(String.format("Account read: %s", object.toXml())));
								}
								link = resourceObjectToLink(object, (Identity) identity.deepCopy((Resolver) context), mainApplication);
							}
						} catch (ConnectorException e) {
							log.warn(LogiPlexTools.stripControls(String.format("Error checking master connector for account: %s", e.getMessage())));
						}
					}

					if (link != null) {
						return link;
					} else {
						log.warn(String.format("No corresponding account found on main application %s for nativeIdentity %s", mainApplication.getName(), nativeIdentity));
					}

					// No suitable link found for nativeIdentity
					List<Link> links = null;
					try {
						service.getLinks(identity, mainApplication, req.getInstance());
					} catch (NullPointerException e) {
						/*
						 * This is likely to happen on the Cloud Gateway without access to the full SailPointContext.
						 * Catch the NullPointer.
						 */
						if (log.isTraceEnabled()) {
							log.error(Util.stackToString(e));
							log.error(LogiPlexTools.stripControls(String.format("Identity: \n%s", (identity != null) ? identity.toXml() : null)));
						} else {
							log.warn("NullPointerException during Links lookup, will try internal method.");
						}
						if (identity != null) {
							links = getLinks(identity, mainApplication, req.getInstance());
						}
					}
					if (links != null && !links.isEmpty()) {
						// If nativeIdentity is null, get first unused account.
						// This will work only for create operations and in part
						// for modify.
						if (Util.isNullOrEmpty(nativeIdentity)) {
							if (AccountRequest.Operation.Create.equals(req.getOperation())) {
								// Find the first unused, or return to create a
								// new account
								for (Link linkToCheck : Util.safeIterable(links)) {
									Link subLink = service.getLink(identity, application, linkToCheck.getInstance(), linkToCheck.getNativeIdentity());
									if (subLink != null) {
										if (log.isDebugEnabled()) {
											log.debug(String.format("Corresponding sub-account on %s found for main account %s; skipping", application.getName(), subLink.getNativeIdentity()));
										}
									} else {
										if (log.isDebugEnabled()) {
											log.debug(String.format("No corresponding sub-account on %s found for main account %s; suitable main account found.", application.getName(),
													linkToCheck.getNativeIdentity()));
										}
										return linkToCheck;
									}
								}
								// Still no corresponding account found - force
								// creation.
								log.info("No suitable main account found, return null to force account creation on main application");
								return null;
							} else {
								// 2019.02.21 - this should not be reached.
								// Currently this method is called only for a
								// Create operation.
								log.warn(String.format("Operation %s should specify an account, but no nativeIdentity found", req.getOperation()));
								if (AccountRequest.Operation.Modify.equals(req.getOperation())) {
									link = links.get(0);
									if (link != null) {
										log.warn(String.format("For operation %s selecting first found main/master account", req.getOperation()));
										return link;
									} else {
										log.error(String.format("No suitable link found for operation %s, returning null", req.getOperation()));
										return null;
									}
								} else {
									log.warn(String.format("Ignoring operation %s for null identityRequest", req.getOperation()));
								}
							}
						} else {
							// Added multiple accounts handling.
							//
							// This point will only be reached if there is a
							// selected account and no corresponding main
							// account
							// can be found. This loop will try to compare based
							// on other attributes.
							Link subLink = service.getLink(identity, application, req.getInstance(), nativeIdentity);
							if (subLink == null) {
								log.error(String.format("Request for native identity %s. No sub-account found on %s. Cannot get corresponding main account. Returning null.", nativeIdentity,
										application.getName()));
								return null;
							}
							// Try to find main account based on sub-account's
							// display name or UUID value.
							String subLinkDisplayName = subLink.getDisplayableName();
							String subLinkUuid = subLink.getUuid();
							if (Util.isNullOrEmpty(subLinkDisplayName) && Util.isNullOrEmpty(subLinkUuid)) {
								log.error(String.format(
										"Request for native identity %s. Sub-account found on %s, but does not have a display name or UUID. Cannot get corresponding main account. Returning null.",
										nativeIdentity, application.getName()));
								return null;
							}
							for (Link linkToCheck : Util.safeIterable(links)) {
								if (linkToCheck != null) {
									// Try UUID
									if (Util.nullSafeEq(linkToCheck.getUuid(), subLinkUuid)) {
										return linkToCheck;
									}
									// Try display name
									if (Util.nullSafeEq(linkToCheck.getDisplayableName(), subLinkDisplayName)) {
										return linkToCheck;
									}
								}
							}
						}
					}
				}
			}

			// Account request is null
			return null;
		}

		/**
		 * Create a Link object from a ResourceObject
		 *
		 * @param object
		 * @param identity
		 * @param application
		 * @return
		 */
		public static Link resourceObjectToLink(ResourceObject object, Identity identity, Application application) {
			Link link = null;
			if (object != null) {
				link = new Link();
				link.setApplication(application);
				link.setIdentity(identity);
				link.setNativeIdentity(object.getIdentity());
				link.setInstance(object.getInstance());
				link.setAttributes(object.getAttributes());
			}
			return link;
		}

		/**
		 * Given an application definition, get all the names of attributes that
		 * are marked as entitlements.
		 *
		 * @param application
		 * @return
		 */
		public static List<String> getAccountEntitlementAttributes(Application application) {
			List<String> attrs = new ArrayList<String>();
			if (application != null) {
				Schema schema = application.getAccountSchema();
				List<String> names = schema.getEntitlementAttributeNames();
				if (names != null && !names.isEmpty()) {
					attrs.addAll(names);
				}
			}
			return attrs;
		}

		/**
		 * Check whether the attribute is listed as an entitlement for the given
		 * application.
		 *
		 * @param application
		 * @param attributeName
		 * @return
		 */
		public static boolean isAccountEntitlementAttribute(Application application, String attributeName) {
			List<String> entitlementNames = getAccountEntitlementAttributes(application);
			return entitlementNames.contains(attributeName);
		}

		/**
		 * Check whether an application attribute is multi-valued.
		 *
		 * @param application
		 * @param attributeName
		 * @return
		 * @throws GeneralException
		 */
		public static boolean isMultiValuedAccountAttribute(Application application, String attributeName) throws GeneralException {
			if (application != null) {
				Schema schema = application.getAccountSchema();
				AttributeDefinition attributeDefinition = schema.getAttributeDefinition(attributeName);
				if (attributeDefinition != null) {
					return attributeDefinition.isMultiValued();
				}
				throw new GeneralException("Attribute not found");
			}
			throw new GeneralException("Application is not set");
		}

		/**
		 * Compare an old and new list of objects and return those that are in
		 * the old list, but not in the new list.
		 *
		 * @param oldList
		 * @param newList
		 * @return
		 */
		public static List<?> getItemsToRemove(List<?> oldList, List<?> newList) {
			if (oldList == null || oldList.isEmpty()) {
				// Empty List.
				return new ArrayList<Object>();
			}
			List<Object> toRemove = new ArrayList<Object>();
			if (newList == null || newList.isEmpty()) {
				// New list is empty, remove all old items
				toRemove.addAll(oldList);
			} else {
				// Add items that are not in the new list to the list of items
				// to be removed.
				for (Object o : oldList) {
					if (!newList.contains(o)) {
						toRemove.add(o);
					}
				}
			}
			return toRemove;
		}

		/**
		 * Compare and old and new list of objects and return those that are in
		 * the new list, but not in the old list.
		 *
		 * @param oldList
		 * @param newList
		 * @return
		 */
		public static List<?> getItemsToAdd(List<?> oldList, List<?> newList) {
			if (newList == null || newList.isEmpty()) {
				// Empty List. Nothing to add/
				return new ArrayList<Object>();
			}
			List<Object> toAdd = new ArrayList<Object>();
			if (oldList == null || oldList.isEmpty()) {
				// New list is empty, remove all old items
				toAdd.addAll(newList);
			} else {
				// Add items that are not in the old list to the list of items
				// to be added.
				for (Object o : newList) {
					if (!oldList.contains(o)) {
						toAdd.add(o);
					}
				}
			}
			return toAdd;
		}

		/**
		 * Take the provisioning results from the provisioned plan and update
		 * the originally requested plan with these results.
		 *
		 * @param originalPlan
		 * @param accountRequest
		 */
		public static void updateResultsInOriginalPlan(ProvisioningPlan originalPlan, AccountRequest accountRequest) {
			if (originalPlan != null && accountRequest != null) {
				AccountRequest matchingAccountRequest = getMatchingAccountRequest(originalPlan, accountRequest);
				if (matchingAccountRequest != null) {
					matchingAccountRequest.setResult(accountRequest.getResult());
				}
			}
		}

		/**
		 * For a given account request, find the corresponding account request
		 * in the originally requested plan.
		 *
		 * @param originalPlan
		 * @param accountRequest
		 * @return
		 */
		public static AccountRequest getMatchingAccountRequest(ProvisioningPlan originalPlan, AccountRequest accountRequest) {
			if (originalPlan != null && accountRequest != null) {
				String trackingId = (String) accountRequest.getArgument(ARG_LOGIPLEX_TRACKING_ID);
				if (Util.isNotNullOrEmpty(trackingId)) {
					List<AccountRequest> originalPlanAccountRequests = originalPlan.getAccountRequests();
					for (AccountRequest originalPlanAccountRequest : originalPlanAccountRequests) {
						if (originalPlanAccountRequest != null) {
							String originalPlanAccountRequestTrackingId = (String) originalPlanAccountRequest.getArgument(ARG_LOGIPLEX_TRACKING_ID);
							if (Util.nullSafeEq(originalPlanAccountRequestTrackingId, trackingId)) {
								return originalPlanAccountRequest;
							}
						}
					}
				}
			}
			return accountRequest;
		}

		/**
		 * On each account request in the original plan, add a tracking ID
		 * (UUID) to the arguments map. This tracking ID is used later on, when
		 * trying to match the provisioned accounts and their original
		 * counterparts.
		 *
		 * @param originalPlan
		 */
		public static void setTrackingIDOnOriginalPlan(ProvisioningPlan originalPlan) {
			List<AccountRequest> originalAccountRequests = originalPlan.getAccountRequests();
			for (AccountRequest originalAccountRequest : Util.safeIterable(originalAccountRequests)) {
				if (originalAccountRequest != null) {
					originalAccountRequest.put(ARG_LOGIPLEX_TRACKING_ID, UUID.randomUUID().toString());
				}
			}
		}

		/**
		 * String ASCII control characters, except for line endings.
		 *
		 * @param input
		 * @return
		 */
		public static String stripControls(String input) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < input.length(); i++) {
				char c = input.charAt(i);
				if ((c <= 0x20 && c != 0x0a && c != 0x0d) || (c >= 0x7f && c <= 0xa0) || (c == 0xad)) {
					sb.append(' ');
				} else {
					sb.append(c);
				}
			}
			return sb.toString();
		}
	}
}
