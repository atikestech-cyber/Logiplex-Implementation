/**
 * 
 */
package sailpoint.services.standard.task;

import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sailpoint.api.SailPointContext;
import sailpoint.connector.CIBInterface;
import sailpoint.connector.Connector;
import sailpoint.connector.ConnectorFactory;
import sailpoint.connector.ConnectorProxy;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;
import sailpoint.object.Resolver;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskSchedule;
import sailpoint.services.standard.connector.LogiPlexConnector;
import sailpoint.task.AbstractTaskExecutor;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;
import sailpoint.tools.Util;
import sailpoint.web.messages.MessageKeys;

/**
 * @author menno.pieters
 * 
 *         This is a specialized task to synchronize LogiPlex enabled
 *         applications to the Cloud Gateway. It should be used next to the
 *         standard Cloud Gateway Synchronization Task.
 *
 */
public class LogiPlexCloudGatewaySync extends AbstractTaskExecutor {

	private static Log log = LogFactory.getLog(LogiPlexCloudGatewaySync.class);
	private boolean terminated = false;

	/**
	 * 
	 */
	public LogiPlexCloudGatewaySync() {
		super();
		if (log.isDebugEnabled()) {
			log.debug("Constructor: LogiPlexCloudGatewaySync()");
		}
	}

	/**
	 * Get the Cloud Gateway Connector.
	 * 
	 * @param cgw
	 * @param taskResult
	 * @return
	 * @throws GeneralException
	 */
	private CIBInterface getCIBConnector(Application cgw, TaskResult taskResult) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getCIBConnector(%s, %s)", cgw, taskResult));
		}
		Connector connector = ConnectorFactory.getConnector(cgw, null);
		if (connector != null && (((ConnectorProxy) connector).getInternalConnector()) instanceof CIBInterface) {
			return (CIBInterface) ((ConnectorProxy) connector).getInternalConnector();
		} else {
			taskResult.addMessage(new Message(Message.Type.Error, MessageKeys.ERR_CANNOT_INSTANTIATE_CLOUD_CONNECTOR));
			return null;
		}
	}

	/**
	 * Clone the application, remove proxy remove LogiPlex attributes, set real
	 * connector and send it to the Cloud Gateway.
	 * 
	 * @param context
	 * @param cgw
	 * @param application
	 * @param taskResult
	 * @throws Exception
	 */
	private void syncLogiPlexApplication(SailPointContext context, Application cgw, Application application, TaskResult taskResult) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: syncLogiPlexApplication(%s, %s, %s, %s)", context, cgw, application, taskResult));
		}
		if (context != null && cgw != null && application != null && taskResult != null) {
			CIBInterface cibif = getCIBConnector(cgw, taskResult);
			if (cibif != null) {
				Application appClone = (Application) application.deepCopy((Resolver) context);
				appClone.removeAttribute("ProxyApplication");
				appClone.setConnector(appClone.getStringAttributeValue(LogiPlexConnector.LOGIPLEX_ATTR_MASTER_CONNECTOR));
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_MASTER_CONNECTOR);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_AGGREGATION_RULE);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_MASTER_APPLICATION);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_CGW_APPLICATION);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_CGW_PROXY_APPLICATION);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_LINK_FROM_MASTER);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_PROVISION_GET_OBJECT);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_RE_AGGREGATE_DELAY);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_SIMULATE_PROVISIONING);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_SIMULATE_PROVISIONING_RESULT);
				appClone.removeAttribute(LogiPlexConnector.LOGIPLEX_ATTR_PREFIX);
				cibif.syncApplicationObject(appClone);
			}
		}
	}

	@Override
	public void execute(SailPointContext context, TaskSchedule taskSchedule, TaskResult taskResult, Attributes<String, Object> args) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: execute(%s, %s, %s, %s)", context, taskSchedule, taskResult, args));
		}

		Filter filter = Filter.and(Filter.eq("connector", "sailpoint.services.standard.connector.LogiPlexConnector"), Filter.isnull("proxy"));
		QueryOptions qo = new QueryOptions();
		qo.addFilter(filter);
		qo.addOrdering("name", true);
		Iterator<Application> iterator = context.search(Application.class, qo);
		int syncedApps = 0;
		while (!terminated && iterator != null && iterator.hasNext()) {
			Application application = iterator.next();
			if (application != null) {
				String cgwApplicationName = application.getStringAttributeValue(LogiPlexConnector.LOGIPLEX_ATTR_CGW_APPLICATION);
				if (Util.isNotNullOrEmpty(cgwApplicationName)) {
					Application cgwApplication = context.getObjectByName(Application.class, cgwApplicationName);
					if (cgwApplication != null) {
						try {
							syncLogiPlexApplication(context, cgwApplication, application, taskResult);
							syncedApps++;
						} catch (Exception e) {
							taskResult.addException(e);
						}
					}
				}
			}
		}
		taskResult.addInt("synchronizedApplications", syncedApps);
	}

	@Override
	public boolean terminate() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: terminate()");
		}
		this.terminated = true;
		return terminated;
	}

}
